select * from iexp..SPO 

/*�u���ƥ��ɮ�*/
SELECT  [PubNo],[STORID],[STORID2],[SD],[SONO],[itemNo],[SKU],[EAN],[DESCR],[QTY],[�ӷ�],[�Ƶ�],[sfile],[etyps]
  FROM [iexp].[dbo].[SPO]
select * from OPENROWSET('Microsoft.ACE.OLEDB.12.0','Excel 12.0; DATABASE=\\192.168.1.33\sjob\IMP\EXCEL\���o�榡 - ��T_V1.xlsx', [�u�@��1$])  as A  
/*�ϥ�Sa�b���n�J�~���v�u�i�ϥδ���פJ*/
--insert into [iexp].[dbo].[SPO]
  ([PubNo]
      ,[STORID]
      ,[STORID2]
	  ,[SKU]
	  ,[QTY]
	  ,[sfile]
)
  select site,storid,[STORID2],sku,qty,sfile
  from OPENROWSET('Microsoft.ACE.OLEDB.12.0','Excel 12.0; DATABASE=\\192.168.1.33\sjob\IMP\EXCEL\���o�榡 - ��T_V1.xlsx', [�u�@��1$])  as A  


--delete iexp..SPO
--192.168.1.33
select * from iexp..SPO  order by sono
where pubno = 'GA07'


--192.168.1.134
--insert into 
select top 200 * from [192.168.1.134].ecaps.dbo.tx_som with (nolocK) where left(sono,2) = 'NG' 
select top 200 * from [192.168.1.134].ecaps.dbo.tx_sod with (nolocK) where left(sono,2) = 'NG'

select  sono,storid,count(distinct storid) from iexp..spo group by sono,storid order by 1

/*��s�渹*/
select sfile , SONO1= 'NG'+right('0000000000'+convert(nvarchar(20),ROW_NUMBER() OVER(  ORDER BY sfile )+37),8)
from iexp..SPO  group by sfile 

--begin tran
--select sfile , SONO1= 'NG'+right('0000000000'+convert(nvarchar(20),ROW_NUMBER() OVER(  ORDER BY sfile )+37),8)
--from iexp..SPO  group by sfile 
--update SPO set SONO = SONO1
--from ( 
--select sfile , SONO1= 'NG'+right('0000000000'+convert(nvarchar(20),ROW_NUMBER() OVER(  ORDER BY sfile )+37),8)
--from SPO  group by sfile 
--) as A
--where A.sfile=SPO.sfile
--select sfile , SONO
--from iexp..SPO  group by sfile,SONO
--order by 2
--rollback tran

select sfile,sono
from iexp..spo 
where 1=1
--and sono = 'NG00000019'
group by sono,sfile
order by 2


/*��sltemno*/
select sono,sku,itemno = right('00000'+ convert(nvarchar(5),ROW_NUMBER() OVER( PARTITION  by sono ORDER BY sku  )),5)
from iexp..SPO  

--begin tran
--update SPO set itemno = a.itemno
--from ( 
--select sono,sku,itemno = right('00000'+ convert(nvarchar(5),ROW_NUMBER() OVER( PARTITION  by sono ORDER BY sku  )),5)
--from iexp..SPO  
--) as A
--where A.sono=SPO.sono
--and a.sku = spo.sku
--select *
--from iexp..SPO  
--order by sono,itemNo
--rollback tran
/*��sSKU���*/
select a.ean,a.descr,b.BUSR2,b.DESCR,* 
from iexp..spo (nolocK) a
left join iexp..skuD (nolocK) b
on '00000' + a.sku = b.sku 
and b.STORERKEY = '01DB'

begin tran
update iexp..spo
set ean = b.BUSR2
,descr = b.DESCR
from iexp..spo (nolocK) a
left join iexp..skuD (nolocK) b
on '00000' + a.sku = b.sku 
and b.STORERKEY = '01DB'
rollback tran



/*��s�@�~���O�N��*/
begin tran
update iexp..spo set SD = Case when STORID = 'O-���o���P' then '9904'
							when STORID = 'O-���o���P' then '9903'
							when STORID = 'X-�����o���P' then '9901'
							when STORID = 'X-�����o���P' then '9902'
						end
from iexp..spo
--where  sono = 'NG00000017'
rollback tran


/*�@�~�渹���*/
/*���O�[�`*/
select sfile N'�ɮצW��' 
,sono N'�@�~�渹'
,PUbno N'����'
,STORID N'����'
,SD as N'�����N��'
,sum(qty) N'�ƶq'
from iexp..spo 
where 1=1
--AND sono = 'NG00000025'
group by sfile,sono,pubno,STORID,sd
order by 2

/*�f���[�`*/
select sfile N'�ɮצW��' 
,sono N'�@�~�渹'
,PUbno N'����'
,sku N'�f��'
,EAN N'ENCode'
,Descr N'�~�W'
,STORID N'����'
,SD as N'�����N��'
,sum(qty) as N'�ƶq' 
from iexp..spo 
where 1=1
--sono = 'NG00000025'
group by 
 sfile 
,sono 
,PUbno 
,sku 
,EAN 
,Descr 
,STORID 
,SD 
order by 2


select * from [192.168.1.134].ecaps.dbo.tx_som with (nolocK) where sono = 'NG00000023'
select * from [192.168.1.134].ecaps.dbo.tx_sod with (nolocK) where sono = 'NG00000023'



---- �פJWES �@�~�� formate
---- �Ш̭Ӯ׽վ�T�w��
--insert [192.168.1.134].ECaps.dbo.TX_SOM( SONO,DOC_TYPE,OP_TYPE,DOCSHIP_TYPE,TRANSTYPE,GRPID,PROVIDER,COMPANY,CMP_NAME,SORTERBATCHNUM,PRIORITY,CLOSE_FLAG,TODAYBATCH_FLAG,DONE,CHECKSUM,CRETDATE,MODDATE,MODID,NOTES,WHC_FLAG,CTQTY )
select  SONO ,DOC_TYPE ='1' , OP_TYPE=0 , DOCSHIP_TYPE='ZP' , TRANSTYPE='C' 
,   GRPID='', PROVIDER='01DBSDB99' , COMPANY=PubNo , CMP_NAME=STORID2
,SORTERBATCHNUM=NULL , PRIORITY=5,   CLOSE_FLAG='00', TODAYBATCH_FLAG='00'
, DONE=0 , CHECKSUM=COUNT(*) ,CRETDATE =GETDATE() ,MODDATE=GETDATE() 
,MODID='EDL\JackyHsu' ,NOTES='',  WHC_FLAG ='00' ,CTQTY=0
from  SPO   
where 1=1
--AND not exists( select * from [192.168.1.134].ECaps.dbo.TX_SOM as M  where M.SONO=SPO.SONO)
--and sono in ('NG00000025')
group by  SONO  , sfile ,PubNo,STORID2

select top 20 * from [192.168.1.134].ECaps.dbo.TX_SOM with (nolocK) where sono = 'NG00000020'

---- �פJWES �@�~����� formate

--insert [192.168.1.134].ECaps.dbo.TX_SOD(SONO,DOC_TYPE,DOCSHIP_TYPE,SEQ,POKEY,PO_SEQ,STOKEY,STO_SEQ,PROVIDER,STOREID,SORTERBATCHNUM,STORENAME,CATID,CATNAME,PRIORITY,SKU,BARCODE,ISBN,DESCR,OPENQTY,ACTQTY,PRICE,DISCOUNT,EDITION,EDITION_NAME,DEFAULT_STORELOC,PATHID,CLOSE_FLAG,CRETDATE,CRETID,MODDATE,MODID,NOTES,AUTHOR,STQ_SEQ,SUSR4,SECAQTY,SORTERBATCHNUM2)
select    
SONO,DOC_TYPE='1' 
,DOCSHIP_TYPE='ZP' 
,SEQ= itemno
, POKEY= SONO 
,PO_SEQ = itemno
,STOKEY= SONO 
,STO_SEQ = itemno
,PROVIDER='01DBSDB99' ,
STORID = storid  ,  SORTERBATCHNUM=NULL ,STORENAME=STORID2  
,CATID='@'+SD ,CATNAME=STORID2 ,   PRIORITY=5,  SKU, BARCODE =EAN,ISBN='' , 
DESCR ,OPENQTY=QTY,ACTQTY=0, PRICE=100 ,DISCOUNT=0 ,EDITION='',EDITION_NAME=''
,  DEFAULT_STORELOC='RETURN', PATHID='0001'  ,CLOSE_FLAG='00',  CRETDATE=GETDATE() 
,CRETID='EDL\JackyHsu',MODDATE=GETDATE(),MODID='',NOTES=[�Ƶ�],   AUTHOR='', STQ_SEQ='' 
,SUSR4='', SECAQTY=0,SORTERBATCHNUM2=''
from  SPO   
where 1=1

select * from [192.168.1.134].ECaps.dbo.TX_SOM with (nolocK) 
where sono in (
 'NG00000038'
,'NG00000039'
,'NG00000040'
,'NG00000041'
,'NG00000042'
,'NG00000043'
,'NG00000044'
,'NG00000045'
,'NG00000046'
,'NG00000047'
,'NG00000048'
,'NG00000049'
,'NG00000050'
,'NG00000051'
,'NG00000052')


select * from [192.168.1.134].ECaps.dbo.TX_SOD with (nolocK)
where sono in (
 'NG00000038'
,'NG00000039'
,'NG00000040'
,'NG00000041'
,'NG00000042'
,'NG00000043'
,'NG00000044'
,'NG00000045'
,'NG00000046'
,'NG00000047'
,'NG00000048'
,'NG00000049'
,'NG00000050'
,'NG00000051'
,'NG00000052')


/*�@�~��Ƨ��*/
SELECT sono AS N'�渹',
boxid AS N'�c��',
SKU,BARCODE AS N'�ӫ~�X',
DESCR AS N'�ӫ~�W',
sum(PACKQTY)N'PCS�`��',
STOREID AS N'�B�z�覡' 
--,SORTERBATCHNUM
--,*
FROM  [192.168.1.134].ECaps.dbo.tx_BOXD with (nolock) 
where sono in (select SONO from [192.168.1.134].ECaps.dbo.tx_soM with (nolock) WHERE sono = 'NG00000049')
group by sono,BOXID,SKU,BARCODE,DESCR,STOREID



/*Sorter�@�~��ƧR��*/
--EXEC ReleasSO '00000725'

/*�L�k�ѧ�ɧR��*/
DECLARE @Batch_NO nvarchar(20) = ''

--delete [CHUTEPC].PAS.dbo.TYYMMDD_A where   Batch_NO=@Batch_NO
--delete [CHUTEPC].PAS.dbo.TYYMMDD_B where   Batch_NO=@Batch_NO
--delete [CHUTEPC].PAS.dbo.TYYMMDD_C where   Batch_NO=@Batch_NO
--delete [CHUTEPC].PAS.dbo.TYYMMDD_Q where   Batch_NO=@Batch_NO 
--delete [192.168.1.134].ECaps.dbo.SORTER_SOD where SORTERBATCHNUM = @Batch_NO
--update [192.168.1.134].ECaps.dbo.TX_SOD set SORTERBATCHNUM=null , CLOSE_FLAG='00' where  SORTERBATCHNUM= @Batch_NO
--update [192.168.1.134].ECaps.dbo.TX_SOM set SORTERBATCHNUM=null , CLOSE_FLAG='00' where  SORTERBATCHNUM= @Batch_NO

--select * from [192.168.1.134].ECaps.dbo.TX_SOM where SORTERBATCHNUM = '10000928'
--select * from [192.168.1.134].ECaps.dbo.TX_SOD where SORTERBATCHNUM = '10000928'
--select * from [192.168.1.134].ECaps.dbo.SORTER_SOD with (nolocK) where SORTERBATCHNUM='10000928'
DECLARE @Batch_NO nvarchar(20) = ''
select * from [CHUTEPC].PAS.dbo.TYYMMDD_A where Batch_NO=@Batch_NO
select * from [CHUTEPC].PAS.dbo.TYYMMDD_B where Batch_NO=@Batch_NO
select * from [CHUTEPC].PAS.dbo.TYYMMDD_C where Batch_NO=@Batch_NO
select * from [CHUTEPC].PAS.dbo.TYYMMDD_Q where Batch_NO=@Batch_NO
select * from [CHUTEPC].PAS.dbo.TYYMMDD_Q where left(slip_no,2) = 'NG'

--DECLARE @Batch_NO nvarchar(20) = '10000932'
--insert into iexp..TYYMMDD_A_202209
--select * from [CHUTEPC].PAS.dbo.TYYMMDD_A where Batch_NO=@Batch_NO
--insert into iexp..TYYMMDD_B_202209
--select * from [CHUTEPC].PAS.dbo.TYYMMDD_B where Batch_NO=@Batch_NO
--insert into iexp..TYYMMDD_C_202209
--select * from [CHUTEPC].PAS.dbo.TYYMMDD_C where Batch_NO=@Batch_NO
--insert into iexp..TYYMMDD_Q_202209
--select * from [CHUTEPC].PAS.dbo.TYYMMDD_Q where Batch_NO=@Batch_NO
--insert into iexp..TYYMMDD_R_202209
--select * from [CHUTEPC].PAS.dbo.TYYMMDD_R where Batch_NO=@Batch_NO

select * from iexp..TYYMMDD_A_202209 (nolocK)
select * from iexp..TYYMMDD_B_202209 (nolocK)
select * from iexp..TYYMMDD_C_202209 (nolocK)
select * from iexp..TYYMMDD_Q_202209 (nolocK)
select * from iexp..TYYMMDD_R_202209 (nolocK)

select sum(qty) from TYYMMDD_C_202209 (nolocK)
select sum(rqty) from TYYMMDD_Q_202209 (nolocK)

select * from iexp..TYYMMDD_A_202209 (nolocK) where CHUTE_NO = '007' --and case_no = '00029'
select * from iexp..TYYMMDD_C_202209 (nolocK) where CHUTE_NO = '007' --and case_no = '00029'
select * from iexp..TYYMMDD_Q_202209 (nolocK) where CHUTE_NO = '007' and RECORD_NO = '00029'


select Close_flag ,* from [192.168.1.134].ECaps.dbo.TX_SOM with (nolocK) where sono = 'NG00000031'
select Close_flag ,* from [192.168.1.134].ECaps.dbo.TX_SOD with (nolocK) where sono = 'NG00000031'

--update Close_flag set close_flag = '80' from [192.168.1.134].ECaps.dbo.TX_SOM with (nolocK) where sono = 'NG00000031'
--update Close_flag set close_flag = '80' from [192.168.1.134].ECaps.dbo.TX_SOD with (nolocK) where sono = 'NG00000031'