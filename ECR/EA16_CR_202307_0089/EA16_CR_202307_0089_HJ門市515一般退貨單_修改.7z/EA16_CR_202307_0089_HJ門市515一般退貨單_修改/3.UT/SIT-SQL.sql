BEGIN TRAN
INSERT INTO SAPI.dbo.SP33  ([clientcode], [BSART], [EBELN], [EKGRP], [RESWK], [BEDAT], [LFART], [KIFNR], [EBELP], [WAMNG], [MEINS], [value1], [MATKL], [werks], [lgort], [value3], [menge], [BUDAT], [MATNR], [ZZINTYP], [value4], [value5], [value6], [IHREZ], [UNSEZ], [ZMSMNO], [ZOMSNM], [ZECNUM], [vas_flag], [vas], [packing_flag], [packing], [expiration_control_flag], [value_flag], [fragile_flag], [inventory_flag], [edlinf], [edltype], [edate], [etyps], [sfile])
Select TOP 1 
	[clientcode], [BSART], '5150224721', [EKGRP], [RESWK], [BEDAT], [LFART], [KIFNR], [EBELP], [WAMNG], [MEINS], [value1], [MATKL], [werks]
	, '0004'
	, [value3], [menge], [BUDAT], [MATNR], [ZZINTYP], [value4], [value5], [value6], [IHREZ], [UNSEZ], [ZMSMNO], [ZOMSNM], [ZECNUM], [vas_flag], [vas], [packing_flag], [packing], [expiration_control_flag], [value_flag], [fragile_flag], [inventory_flag], [edlinf], 'RPO', [edate], '0', 'kyeli_test_20230824_1' 
from SAPI.dbo.SP33_BK with (Nolock)  
where BSART = 'ZS15'  
and EBELN = '5150224726'
ROLLBACK TRAN

/*********************************************/
DECLARE 
	  @Mod1   NVarchar(10)   = ''
	, @Mod2   NVarchar(10)   = ''
	, @UserID NVarchar(10)   = ''
	, @Sfile  Nvarchar(200)  = 'kyeli_test_20230824_1' 
	, @Msg1   NVarchar(100)  = ''

EXEC Iexp.[dbo].[Eslite_Sap_Sp33_Imp_Fun] 
	  @Mod1   
	, @Mod2   
	, @UserID 
	, @Sfile   
	, @Msg1    Output 

SELECT @Msg1

/*********************************************/
SELECT * FROM SAPI.dbo.SP33 WITH (NOLOCK) 

Select * from [HJWMS].AAD.dbo._v_lookup with (nolock) WHERE locale_id = '1028'  and source like '%po%' and lookup_type = 'Status'

/*********************************************/
--0001 
--��f�n�O�� : AP2308240001
SELECT lgort,* FROM SAPI.dbo.SP33_BK WITH (NOLOCK) WHERE [EBELN] = '5150224720'
SELECT cfile,* FROM IEXP.dbo.W_PO WITH (NOLOCK) WHERE display_po_number = '5150224720'
SELECT lot_number_3,* FROM IEXP.dbo.W_POD WITH (NOLOCK) WHERE display_po_number = '5150224720'
Select * from [HJWMS].AAD.dbo._tv_po_master with (nolock) WHERE display_po_number = '5150224720'
Select erp_wh,* from [HJWMS].AAD.dbo._tv_po_detail with (nolock) WHERE display_po_number = '5150224720'
SELECT * FROM SJOB.dbo.JOBQ WITH (NOLOCK) WHERE Lotkey2 = '5150224720'

--0004
SELECT lgort,* FROM SAPI.dbo.SP33_BK WITH (NOLOCK) WHERE [EBELN] = '5150224721'
SELECT cfile,* FROM IEXP.dbo.W_PO WITH (NOLOCK) WHERE display_po_number = '5150224721'
SELECT lot_number_3,* FROM IEXP.dbo.W_POD WITH (NOLOCK) WHERE display_po_number = '5150224721'
Select * from [HJWMS].AAD.dbo._tv_po_master with (nolock) WHERE display_po_number = '5150224721'
Select erp_wh,* from [HJWMS].AAD.dbo._tv_po_detail with (nolock) WHERE display_po_number = '5150224721'
SELECT * FROM SJOB.dbo.JOBQ WITH (NOLOCK) WHERE Lotkey2 = '5150224721'

--NULL
SELECT lgort,* FROM SAPI.dbo.SP33_BK WITH (NOLOCK) WHERE [EBELN] = '5150224722'
SELECT cfile,* FROM IEXP.dbo.W_PO WITH (NOLOCK) WHERE display_po_number = '5150224722'
SELECT lot_number_3,* FROM IEXP.dbo.W_POD WITH (NOLOCK) WHERE display_po_number = '5150224722'
Select * from [HJWMS].AAD.dbo._tv_po_master with (nolock) WHERE display_po_number = '5150224722'
Select erp_wh,* from [HJWMS].AAD.dbo._tv_po_detail with (nolock) WHERE display_po_number = '5150224722'
SELECT * FROM SJOB.dbo.JOBQ WITH (NOLOCK) WHERE Lotkey2 = '5150224722'

/*********************************************/