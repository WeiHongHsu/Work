
/****
 =============================================================================================
 Author			: Calvin
 ALTER Date	: 2020.04.21
 Description	: Sap SP33 單據轉入w_Po，w_So
 Test SQL		: Exec  Eslite_Sap_Sp33_Imp_Fun '','','Sa' ,'Sfile' ,''
 =============================================================================================
 Author			: Calvin
 Alter Label	: 
 Alter Date		: 2020.08.03
 Description	: 新增通過型計算
 =============================================================================================
 Author			: Calvin
 Alter Date		: 2020.09.22 515依在庫標誌修改倉別
 Alter Date		: 2020.10.14  WAMNG調整成menge
 Alter Date		:   ken : 20210318_ken 401單據近來調整
 =============================================================================================
 Author			: Kevin
 Alter Date		: 2022.01.24 WAMNG, menge convert Money to INT
 =============================================================================================
 Author			: Kevin
 Alter Date		: 2022.06.16 Add XSO for 香港調撥
 =============================================================================================
 Author Label	: Raines_0919
 Author			: Raines
 Alter Date		: 2022.09.19 change menge to WAMNG
 =============================================================================================
 Author Label	: KL01
 Author			: KyeLi
 Alter Date		: 2023.06.19 Modified Default Facility 
 =============================================================================================
 
 Test Data		: 
****/
CREATE PROCEDURE [dbo].[Eslite_Sap_Sp33_Imp_Fun] ( 
	@Mod1 NVarchar(10), @Mod2 NVarchar(10) , 
	@UserID NVarchar(10) , @Sfile Nvarchar(200) ,
	@Msg1 NVarchar(100) Output 
	)
AS
BEGIN
	--SET NOCOUNT ON;
	--變數宣告
	DECLARE @SPNo AS Int = 0 , @RowCount As Int
	DECLARE @it33 AS Int   , @Key1 As Varchar(30)  , @Key2 As Varchar(30)   , @Key3 As Varchar(30) , @Key4 As Varchar(30) ,  @etyps as int  ,  @Cntl as int=0

	--變數宣告
    Print 'Eslite_Sap_Sp33_Imp_Fun 主檔匯入 Start'
	Update Sapi..SP33 Set etyps = 1 , @SPNo = 1 Where etyps = 0
    --處理數字
    --Previous version:  Update Sapi..SP33 Set WAMNG = Replace(WAMNG , ',','') , menge =  Replace(menge , ',','') Where etyps = 1
    Update Sapi..SP33 Set WAMNG = Replace(Replace(Replace(WAMNG , ',',''),'.000',''),' ','') , menge =  Replace(Replace(Replace(menge , ',',''),'.000',''),' ','') Where etyps = 1
    -- Previous version: Update Sapi..SP33 Set EBELN =left(EBELN ,10) Where etyps = 1 and  clientcode = 'EHK' 
    -- SP33 is fixed column by character length, so it will have many blank characters. cut length 10 for order number - modify by Kevin on 12/20/2021
    Update Sapi..SP33 Set EBELN =left(EBELN ,10) Where etyps = 1 -- and  clientcode = 'EHK' 

    --排除GR
    Update Sapi..SP33 Set etyps = -99 Where etyps = 1 And value5 Like '500%'

    --排除發貨單位F001的GI單
	Update Sapi..SP33 Set etyps = -98 Where etyps = 1 And value5 Like '500%' And RESWK = 'F001'
    --更新BUDAT
    Update Sapi..SP33 Set BUDAT = CONVERT(varchar(8), Getdate() , 112) Where ISDATE(BUDAT ) = 0 And etyps = 1
    --更新ZOMSNM
    Update Sapi..SP33 Set ZOMSNM = ZECNUM Where ZOMSNM = '' And etyps = 1

	Update SAPi..SP33 Set 
		etyps = case when Isnull (_ErpImpLogic.EDLType ,'')='' then -1199 else 9 end ,
		werks = _ErpImpLogic.Erp_Site_Re , EdlInf = _ErpImpLogic.EDLInf ,EdlType = _ErpImpLogic.EDLType 
        -- Sap未給倉別先壓上倉別
        --, LGORT = _ErpImpLogic.Erp_Site_Ex_Re 
		, LGORT = CASE WHEN ISNULL(LGORT,'') = '' THEN _ErpImpLogic.Erp_Site_Ex_Re  ELSE LGORT END --(KL01)
 	from  _ErpImpLogic With (Nolock)
	where InterFace = 'SP33' 
		And _ErpImpLogic.client_code = SAPi..SP33.clientcode 
		And _ErpImpLogic.Erp_Site = SAPi..SP33.werks  
		-- 開放所有單  And _ErpImpLogic.ErpType = SAPi..SP33.bsart (BEN said the rule should be added)
		And _ErpImpLogic.ErpType = SAPi..SP33.bsart 
		and  _ErpImpLogic.EDLInf In ('PO'  ) 
		And Sapi..SP33.etyps = 1 And _ErpImpLogic.Etyps = 9

    --更換單號
    Update Sapi..SP33 Set value5 = EBELN , value6 = Right(EBELP,4) Where werks = '1300' And value5 = '8888888888'
    Update Sapi..SP33 Set value5 = EBELN , value6 = Right(EBELP,4) Where value5 = '8888888888'

    --需要補上401單要更新client code ，erp_SITE與SKU  20210318_ken  BK01	ZR01
	-- Sapi..SP33 no backuped to Sapi..SP33_BK, so Sapi..SP33_BK will be changed value
	-- The scipt is changed 27 code to 26 code when 401+EHK
	IF exists(Select * From Sapi..SP33 Where ebeln like '401%'  and  clientcode = 'EHK' )
	Begin
		-- Pervious code, change by Kevin on 1/3/2022
		--Update Sapi..SP33 set  clientcode = 'ESL' ,werks = 'F002',IHREZ=KIFNR  , ZMSMNO=MATNR     where sp33.ebeln like '401%'  and sp33.clientcode = 'EHK'
		--Update Sapi..SP33 set sp33.MATNR = display_item_number_ex  
		--  from iexp..m_SkuMapping sku with (nolock) 　
		-- where sp33.ebeln like '401%'  and sp33.clientcode = 'EHK'
		--   and sku.erp_site_ex = 'F001'　 and sku.client_code = 'EHK'
		--   and sp33.MATNR = sku.display_item_number

	   --Update  Sapi..SP33   Set etyps = 9 ,  MATNR=SKU ,KIFNR=K.SUSR1  from [192.168.1.33].iexp.dbo.SKUD as K
		--		WHERE K.STORERKEY='01DB'  and MATNR like '0000027%' and  MATNR=K.HK27
		
		Update SP33 -- Sapi..SP33 
		Set SP33.clientcode = 'ESL'
		,SP33.werks = 'F002'
		,SP33.etyps = 9 
		,SP33.MATNR = MSM.display_item_number_ex --27 code change to 26 code
		,SP33.KIFNR = MSM.preferred_Y --Vendor code
		FROM Sapi..SP33 AS SP33
		INNER JOIN iexp..V_SkuMapping AS MSM WITH (NOLOCK) --View table for combine m_SkuMapping & m_sku
		ON MSM.erp_site = 'F002'
		AND SP33.clientcode = MSM.client_code
		AND SP33.MATNR = MSM.display_item_number -- 27 code mapping
		WHERE SP33.clientcode = 'EHK'
		AND LEFT(SP33.EBELN,3) = '401'
		
	END

	--異常資料處理
	Update SP33 Set etyps = - 1170 From Sapi..SP33 As SP33 , w_Po 
		Where SP33.clientcode = w_Po.client_code And SP33.werks = w_Po.erp_site And SP33.value5 = w_Po.display_po_number 
			And w_Po.Ctyps <> 0 And SP33.EdlType In ('WPO') And SP33.etyps = 9 

	Update SP33 Set etyps = - 1170 From Sapi..SP33 As SP33 , w_Po 
		Where SP33.clientcode = w_Po.client_code And SP33.werks = w_Po.erp_site And SP33.EBELN  = w_Po.display_po_number 
			And w_Po.Ctyps <> 0 And SP33.EdlType In ('PO','RPO') And SP33.etyps = 9 

	Print 'PO重複單據數量：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'
    -- STATE report   bsart /     S012 /S014 ,  werks
	Select  top 1 @it33=count(*)  , @Key4 =max(bsart ) , @Key1=  max(werks)   , @Key2=MAX(EBELN)  ,  @Key3=max(EdlType),  @Key4=max(Edlinf), @Cntl=max(etyps)  From Sapi..SP33   Group By sfile

    --整批備份
	If (Select Count(*) From Sapi..SP33 ) > 0 
	Begin
		Print '整批資料進行備份'
		Insert Into Sapi..SP33_BK Select * From Sapi..SP33  
	End
	-- Print   @Key1  + ' 單(類型):'+ @Key2 +' (' +@Key4+ ' /' +@Key2+  ')：'+ + Cast(@it11 as varchar(6)) + ' 筆 Types: ' + Cast(@Cntl  as varchar(6))
 
	If (Select Count(*) From Sapi..SP33 Where etyps <= 1 ) > 0 
	Begin
		Print '異常資料轉移至異常區'
		Insert Into Sapi..SP33_Error Select * From Sapi..SP33 Where etyps <= 1
		If @@ROWCOUNT > 0 
		Begin
			Delete From Sapi..SP33 Where etyps <= 1
		End
	End
	--異常資料處理
    
	Select @RowCount = Count(*) From Sapi..SP33 Where etyps = 9 And EdlType In ('PO','RPO')
	If (@RowCount) > 0 
	Begin
        Print '類型：Po/RPO，w_Po明細轉入數量：' + Cast(@RowCount As varchar(10)) + '筆'
        --加工標記填入
	    --商品類型
	    Update Sapi..SP33 Set vas_flag = 'Y' Where matkl Like '[3,4,5,6,7,F]%' And etyps = 9 
	    Update Sapi..SP33 Set vas_flag = 'Y' Where matkl Like '11[2,3,4,5]%' And etyps = 9 

	    --一號多書
	    Update Sapi..SP33 Set vas_flag = 'Y' 
		    From (Select client_code , erp_site , display_item_number , oean  From iexp..m_Sku ) As m_Sku 
	    Where Sapi..SP33.clientcode = m_Sku.client_code And Sapi..SP33.werks = m_Sku.erp_site 
		    And Sapi..SP33.MATNR = m_Sku.display_item_number And Isnull(m_Sku.oean ,'') <> '' And Sapi..SP33.etyps = 9 
	    --加工標記填入

	    --在庫標誌2020.08.03
	    Update Sapi..SP33 Set inventory_flag = m_Sku.inventory_type
		    From (Select client_code , erp_site , display_item_number , inventory_type From iexp..m_Sku ) As m_Sku 
	    Where Sapi..SP33.clientcode = m_Sku.client_code And Sapi..SP33.werks = m_Sku.erp_site 
		    And Sapi..SP33.MATNR = m_Sku.display_item_number And Sapi..SP33.etyps = 9 
	    --在庫標誌2020.08.03

	    --515依在庫標誌修改倉別2020.09.22
	    Update Sapi..SP33 Set lgort = Case m_Sku.inventory_type When 'Y' Then '0001' Else lgort End
		    From (Select client_code , erp_site , display_item_number , inventory_type From iexp..m_Sku ) As m_Sku 
	    Where Sapi..SP33.clientcode = m_Sku.client_code And Sapi..SP33.werks = m_Sku.erp_site 
		    And Sapi..SP33.MATNR = m_Sku.display_item_number And Sapi..SP33.etyps = 9 And EdlType = 'RPO' And bsart = 'ZS15' And werks = 'F001'
	    --515依在庫標誌修改倉別2020.09.22

        Delete Iexp..w_Pod 
			From Iexp..w_Pod As w_Pod , 
				( Select clientcode , werks , EBELN From Sapi..SP33 Where etyps = 9 And edltype In ('PO','RPO') Group by clientcode , werks , EBELN ) As SP33 
			Where w_Pod.client_code = SP33.clientcode And w_Pod.erp_site = SP33.werks And w_Pod.display_po_number = SP33.EBELN 
		Print '相同單據的明細全部刪除：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

        Insert Into Iexp..w_Pod ( 
			client_code						, erp_site						, display_po_number					, line_number							, 
			ref_po_number					, ref_line_number				, ref_po_number_2					, ref_line_number_2						, 
			item_number						, uom_qty						, uom_qty_received					, uom_qty_damaged						,
			order_uom						, qty							, qty_received						, qty_damaged							, 
			base_uom						, tax_code						, list_price						, discount								, 
			cost							, vas_flag						, vas								, packing_flag							,
			packing							, expiration_control_flag		, value_flag						, fragile_flag							, 
			lot_number						, lot_number_2					, lot_number_3						, lot_number_4							, 
			lot_number_5					, qty_diff						, qty_diff_over						, qty_diff_under						,
			qty_diff_barcode				, qty_diff_noean				, qty_diff_stain					, qty_diff_damaged						, 
			qty_diff_misc					, diff_misc_description			, diff_memo							, Adddate								, 
			Addwho							, Editdate						, Editwho							, comment								,
			Ex1								, Ex2							, Ex3								, Ex4									, 
			Ex5								, Ex6							, Ex7								, Ex8									,
            Etyps                           )
		
        Select 
			SP33.clientcode					, SP33.werks					, SP33.EBELN    					, dbo.FmtNumStr(Cast(EBELP As int),10,0),
			SP33.EBELN						, dbo.FmtNumStr(Cast(EBELP As int),10,0), SP33.EBELN				, dbo.FmtNumStr(Cast(EBELP As int),10,0),
			MATNR         					, Cast(WAMNG As numeric)		, 0								    , 0										,
			meins							, Cast(WAMNG As numeric)		, 0								    , 0										,
			meins							, Null							, Cast(Isnull(m_Sku.list_price,0.00) As money ), m_Sku.discount				,
			Cast(Isnull(m_sku.cost,0.00) As money), Isnull(vas_flag,'N')	, Null								, 'N'									,
			Null							, m_sku.expiration_date_control	, Isnull(Left(m_sku.value_description,1),'N'), m_sku.haz_material			,
			Null							, Isnull(ZOMSNM,ZECNUM )		, Lgort								, Null									,
			Null							, 0								, 0									, 0										,
			0								, 0								, 0									, 0										,
			0								, Null							, Null								, Getdate()								,
			'GateWay_InterFace'				, Getdate()						, 'GateWay_InterFace'				, Null									,
			inventory_type		, preferred_Y				, ean								, Null									,
			Null							, Null							, Null								, Ex8=IHREZ+'/'+ZMSMNO                             ,
            9
		From Sapi..SP33 As SP33 With (Nolock) 
		Left Join Iexp..m_Sku As m_Sku 
		On SP33.clientcode = m_Sku.client_code 
		And SP33.werks = m_Sku.erp_site 
		And SP33.EBELN = m_Sku.display_item_number 
		Where SP33.etyps = 9 And EdlType In ('PO','RPO')

		Print '單據明細新增：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'
--select top 1000	inventory_type , * from  Iexp..m_Sku where erp_site='F001'
		Update Iexp..w_Po Set 
			po_item_count = SP33.po_item_count	, po_total_qty = SP33.po_total_qty		, vas_flag = SP33.vas_flag		,
			packing_flag = SP33.packing_flag	, expiration_control_flag = SP33.expiration_control_flag , value_flag = SP33.value_flag ,
			fragile_flag = SP33.fragile_flag	, create_date = SP33.create_date		, Efile = SP33.Efile			,
			Editdate = Getdate()				, Editwho = 'GateWay_InterFace'
		From (
			Select 
				clientcode As client_code					, werks As erp_site			, EBELN As display_po_number			, 
				Count(Distinct MATNR ) As po_item_count		, Sum(Cast(WAMNG As numeric)) As po_total_qty	, 
				Case Sum(Case vas_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As vas_flag , 
				Case Sum(Case packing_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End	As packing_flag ,
				Case Sum(Case expiration_control_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As expiration_control_flag , 
				Case Sum(Case value_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As value_flag , 
				Case Sum(Case fragile_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As fragile_flag , 
				Cast(Max(BUDAT) As smalldatetime )  As create_date , Sfile As Efile
			From Sapi..SP33 With (Nolock)
			Where etyps = 9 And EdlType In ('PO','RPO')
			Group By clientcode , werks , Sfile , EBELN 
			) As SP33
		Where Iexp..w_Po.client_code = SP33.client_code 
		And Iexp..w_Po.erp_site = SP33.erp_site 
		And Iexp..w_Po.display_po_number = SP33.display_po_number

		Print '相同單據頭檔更新：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

		Insert Into Iexp..w_Po (
			client_code						, erp_site						, Erp_type_text						, type_text								,
			display_po_number				, po_item_count					, so_item_count						, po_total_qty							,
			so_total_qty					, rcv_total_qty					, vendor_code						, vendor_so_number						,
			vendor_so_number_2				, vendor_case_count				, vendor_total_qty					, xdock_line_id							,
			xdock_period					, xdock_device_id				, vas_flag							, packing_flag							,
			expiration_control_flag			, value_flag					, fragile_flag						, create_date							,
			Etyps							, Efile							, Edate								, Espdate								, 
			Rdate							, Rspdate						, Ctyps								, Cfile									,
			Cdate							, Cspdate						, B2Btyps							, B2Bfile								,
			B2Bdate							, B2Bspdate						, Adddate							, Addwho								,
			Editdate						, Editwho						, comment							, Ex1									,
			Ex2								, Ex3							, Ex4								, Ex5									,
			Ex6								, Ex7							, Ex8								)
		Select 
			clientcode						, werks							, bsart								, EdlType								,
			EBELN 							, Count(Distinct MATNR ) 		, 0									, Sum(Cast(WAMNG As numeric))			,
            --在庫標誌計算 2020.08.03
			-- Pervious version: Sum(Case inventory_flag When 'N' Then WAMNG Else 0 End) , Sum(Case inventory_flag When 'N' Then 1 Else 0 End) , RESWK , Null			    ,
			Sum(Case inventory_flag When 'N' Then Cast(WAMNG AS numeric) Else 0 End) , Sum(Case inventory_flag When 'N' Then 1 Else 0 End) , RESWK , Null			    ,
			Null							, Null							, Null								, Null									,
			Null							, Null							, Case Sum(Case vas_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End , Case Sum(Case packing_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End	,
			Case Sum(Case expiration_control_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End , Case Sum(Case value_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End , Case Sum(Case fragile_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End , Max(BUDAT)  ,
			9								, sfile							, Getdate()							, Convert(nvarchar(6), Getdate() , 12)	,
			Null							, Null							, 0									, Null									,
			Null							, Null							, 0									, Null									,
			Null							, Null							, Getdate()							, 'GateWay_InterFace'					,
			Getdate()						, 'GateWay_InterFace'			, Null								, Null									,
			Null							, Null							, Null								, Null									,
			Null							, Null							, Null								
		From Sapi..SP33 With (Nolock)
		Where etyps = 9 And EdlType In ('PO','RPO')
		And Not Exists (Select * From iexp..w_Po With (Nolock)
						Where iexp..w_Po.client_code = Sapi..SP33.clientcode 
						And iexp..w_Po.erp_site = Sapi..SP33.werks 
						And iexp..w_Po.display_po_number = Sapi..SP33.EBELN )

		Group by clientcode , werks , bsart , edlinf , EBELN , RESWK ,  sfile , EdlType
		Print '單據頭檔新增：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

		--------------------------------
		-- XSO Insert for ZS04, E001, E002, E003, E004, E005 調播出貨
		-- Start

		IF Exists ( Select top 1 1 From Sapi..SP33 
				Where etyps = 9 
				And EdlType In ('PO') 
				And BSART = 'ZS04' 
				And Substring(werks,1,1) = 'E' )
		Begin

			Delete Iexp..w_Xsod 
			From Iexp..w_Xsod As w_Xsod , 
				( Select clientcode 
					, werks 
					, EBELN 
					From Sapi..SP33 
					Where etyps = 9 
					And edltype In ('PO')
					And BSART = 'ZS04' 
					And Substring(werks,1,1) = 'E'
					Group by clientcode , werks , EBELN ) As SP33 
			Where w_Xsod.client_code = SP33.clientcode 
			And w_Xsod.erp_site = SP33.werks 
			And w_Xsod.cust_po_number = SP33.EBELN

			Print '相同單據的明細全部刪除：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

			Insert Into w_Xsod (
        	    client_code                     , erp_site                      , Display_order_number              , Display_order_line_number             ,
        	    cust_po_number                  , po_line_number                , order_number                      , order_line_number                     ,
        	    item_number                     , uom_qty                       , uom_qty_shipped                   , order_uom                             ,
        	    qty                             , qty_shipped                   , qty_return                        , base_uom                              ,
        	    tax_rate                        , invoice_number                , invoice_dt                        , invoice_amount                        , 
        	    currency_code                   , tax_code                      , untax_amount                      , tax_amount                            ,
        	    amount                          , invoice_code                  , list_price                        , discount                              ,
        	    cost                            , vas_flag                      , packing_flag                      , expiration_control_flag               ,
        	    value_flag                      , fragile_flag                  , lot_numer                         , lot_number_2                          ,
        	    lot_number_3                    , lot_number_4                  , lot_number_5                      , oms_hold_number                       ,
        	    qty_diff                        , qty_diff_over                 , qty_diff_under                    , qty_diff_barcode                      ,
        	    qty_diff_noean                  , qty_diff_stain                , qty_diff_damaged                  , qty_diff_misc                         ,
        	    diff_misc_description           , diff_memo                     , Adddate                           , Addwho                                ,
        	    Editdate                        , Editwho                       , comment                           , Ex1                                   ,
        	    Ex2                             , Ex3                           , Ex4                               , Ex5                                   ,
        	    Ex6                             , Ex7                           , Ex8                               ,sold_to_code)
        	Select
        	    SP33.clientcode                 , SP33.werks                    , SP33.value5                        , dbo.FmtNumStr(Cast(EBELP As int),10,0),
        	    Left(EBELN,10) As cust_po_number, dbo.FmtNumStr(Cast(EBELP As int),10,0) As po_line_number, value5 As order_number , EBELP As order_line_number    ,
        	    matnr As item_number            , Cast(WAMNG As numeric) As uom_qty , 0 As uom_qty_shipped          , 'EA' As order_uom                     ,
        	    Cast(WAMNG As numeric) As Qty   , 0 As qty_shipped              , 0 As qty_return                   , 'EA' As base_uom                      ,
        	    Null As tax_rate                , Null As invoice_number        , Null As invoice_dt                , Null As invoice_amount                , 
        	    Null As currency_code           , Null As tax_code              , Null As untax_amount              , Null As tax_amount                    ,
        	    Null As amount                  , Null As invoice_code          , Null As list_price                , Null As discount                      ,
        	    Null As cost                    , Isnull(vas_flag , 'N')        , 'N' As packing_flag               , Isnull(m_sku.expiration_date_control,'N') As 	expiration_control_flag ,
        	    Isnull(Left(m_sku.value_description,1),'N') As value_flag , Isnull(m_sku.haz_material,'N') As fragile_flag , Null As lot_numer , Null As 	lot_number_2 ,
        	    '0001' As lot_number_3          , Null As lot_number_4          , Null As lot_number_5              , Null As oms_hold_number               ,
        	    0 As qty_diff                   , 0 As qty_diff_over            , 0 As qty_diff_under               , 0 As qty_diff_barcode                 ,
        	    0 As qty_diff_noean             , 0 As qty_diff_stain           , 0 As qty_diff_damaged             , 0 As qty_diff_misc                    ,
        	    Null As diff_misc_description   , Null As diff_memo             , Getdate() As Adddate              , 'GateWay_InterFace' As Addwho         ,
        	    Getdate() As Editdate           , 'GateWay_InterFace' As Editwho, Null As comment                   , Null As Ex1                           ,
        	    Null As Ex2                     , Null As Ex3                   , Null As Ex4                       , Null As Ex5                           ,
        	    Null As Ex6                     , Null As Ex7                   , Null As Ex8                               ,MATKL
        	From Sapi..SP33 As SP33 With (Nolock) 
			Left Join Iexp..m_Sku As m_Sku 
        	On SP33.clientcode = m_Sku.client_code 
			And SP33.werks = m_Sku.erp_site 
			And SP33.matnr = m_Sku.display_item_number 
        	Where SP33.etyps = 9 And EdlInf In ('Po')
			And SP33.BSART = 'ZS04' 
			And Substring(SP33.werks,1,1) = 'E'
        	Print '單據明細新增：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

			Update Iexp..w_Xso Set 
        	    So_item_count = Temp.item_count	, So_total_qty = Temp.total_qty		, vas_flag = Temp.vas_flag		,
        	    packing_flag = Temp.packing_flag	, expiration_control_flag = Temp.expiration_control_flag , value_flag = Temp.value_flag ,
        	    fragile_flag = Temp.fragile_flag	, Efile = Temp.Efile			,
        	    Editdate = Getdate()				, Editwho = 'GateWay_InterFace'
        	From (
        	    Select 
        	        clientcode As client_code					, werks As erp_site			, EBELN As po_number			, 
        	        Count(Distinct matnr ) As item_count		, Sum(Cast(WAMNG As numeric)) As total_qty	, 
        	        Case Sum(Case vas_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As vas_flag , 
        	        Case Sum(Case packing_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End	As packing_flag ,
        	        Case Sum(Case expiration_control_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As expiration_control_flag , 
        	        Case Sum(Case value_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As value_flag , 
        	        Case Sum(Case fragile_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As fragile_flag , 
        	        Sfile As Efile
        	    From Sapi..SP33 With (Nolock)
				Where etyps = 9 
				And EdlInf In ('Po')
				And BSART = 'ZS04' 
				And Substring(SP33.werks,1,1) = 'E'
        	    Group By clientcode , werks , Sfile , EBELN 
				) As Temp
        	Where Iexp..w_Xso.client_code = Temp.client_code 
			And Iexp..w_Xso.erp_site = Temp.erp_site 
        	And Iexp..w_Xso.cust_po_number = Temp.po_number

        	Print '相同單據頭檔更新：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

			Insert Into w_Xso (
        	    client_code                     , erp_site                      , Erp_type_text                     , type_text                             ,
        	    display_order_number            , cust_po_number                , so_total_qty                      , so_item_count                         ,
        	    so_total_fulfill_qty            , customer_code                 , ship_to_email                     , ship_to_code                          ,
        	    ship_to_description             , ship_to_name                  , ship_to_address                   , ship_to_country_name                  ,
        	    ship_to_state                   , ship_to_city                  , ship_to_zip                       , ship_to_fax                           ,
        	    ship_to_phone                   , cod_type                      , cod_flag                          , cod_amount                            ,
        	    actual_delivery_date            , total_amount                  , print_invoice                     , bill_to_email                         ,
        	    bill_to_code                    , bill_to_description           , bill_to_name                      , bill_to_address                       ,
        	    bill_to_country_name            , bill_to_state                 , bill_to_city                      , bill_to_zip                           ,
        	    bill_to_fax                     , bill_to_phone                 , vas_flag                          , packing_flag                          ,
        	    expiration_control_flag         , value_flag                    , fragile_flag                      , Etyps                                 ,
        	    Efile                           , Edate                         , Espdate                           , Ctyps                                 ,
        	    Cfile                           , Cdate                         , Cspdate                           , B2Btyps                               ,
        	    B2Bfile                         , B2Bdate                       , B2Bspdate                         , Adddate                               ,
        	    Addwho                          , Editdate                      , Editwho                           , comment                               ,
        	    Ex1                             , Ex2                           , Ex3                               , Ex4                                   ,
        	    Ex5                             , Ex6                           , Ex7                               , Ex8                                   )
        	Select
        	    SP33.clientcode As client_code  , werks As erp_site             , 'ZEL' As Erp_type_text            , edlinf As type_text                   ,
        	    value5 As display_order_number   , EBELN As cust_po_number       , Sum(Cast(WAMNG As numeric)) As so_total_qty , Count(Distinct matnr ) As 	so_item_count ,
        	    0 As so_total_fulfill_qty       , 'ESL' As customer_code        , '' As ship_to_email               , werks As ship_to_code                 ,
        	    Iexp..m_Storer_S.site_name_full As ship_to_description , Iexp..m_Storer_S.site_name As ship_to_name , Iexp..m_Storer_S.address As ship_to_address , 	Iexp..m_Storer_S.country As ship_to_country_name ,
        	    '' As ship_to_state             , Iexp..m_Storer_S.city As ship_to_city , Iexp..m_Storer_S.zip_code As ship_to_zip , Iexp..m_Storer_S.fax_number As 	ship_to_fax  ,
        	    '' As ship_to_phone             , Null As cod_type              , 'N' As cod_flag                   , Null As cod_amount                    ,
        	    Null As actual_delivery_date    , Null As total_amount          , 'N' As print_invoice              , '' As bill_to_email                   ,
        	    RESWK As bill_to_code           , Iexp..m_Storer_S.site_name_full As bill_to_description , Iexp..m_Storer_S.site_name As bill_to_name  , Iexp..	m_Storer_S.address As bill_to_address ,
        	    Iexp..m_Storer_S.country As bill_to_country_name , '' As bill_to_state , Iexp..m_Storer_S.city As bill_to_city , Iexp..m_Storer_S.zip_code As 	bill_to_zip ,
        	    Iexp..m_Storer_S.fax_number As bill_to_fax , Iexp..m_Storer_S.phone_number As bill_to_phone , Case Sum(Case vas_flag When 'Y' Then 1 Else 0 End) 	When 0 Then 'N' Else 'Y' End As vas_flag , 'N' As packing_flag ,
        	    Case Sum(Case expiration_control_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As expiration_control_flag , Case Sum(Case value_flag 	When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As value_flag , Case Sum(Case fragile_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 	'Y' End As fragile_flag , 9 As Etyps ,
        	    Sapi..SP33.sfile As Efile       , Getdate() As Edate            , Convert(nvarchar(6), Getdate() , 12) As Espdate , 0 As Ctyps              ,
        	    Null As Cfile                   , Null As Cdate                 , Null As Cspdate                   , Null As B2Btyps                       ,
        	    Null As B2Bfile                 , Null As B2Bdate               , Null As B2Bspdate                 , Getdate() As Adddate                  ,
        	    'GateWay_InterFace' As Addwho   , Getdate() As Editdate         , 'GateWay_InterFace' As Editwho    , Null As comment                       ,
        	    Null As Ex1                     , Null As Ex2                   , Null As Ex3                       , Null As Ex4                           ,
        	    Null As Ex5                     , Null As Ex6                   , Null As Ex7                       , Null As Ex8                                   
        	From Sapi..SP33 With (Nolock)
			Left Join Iexp..m_Storer_S With (Nolock)
			On Sapi..SP33.clientcode = Iexp..m_Storer_S.customer_code 
			And Sapi..SP33.RESWK = Iexp..m_Storer_S.site_code 
			Where etyps = 9 And EdlInf In ('Po')
			And BSART = 'ZS04' 
			And Substring(werks,1,1) = 'E'
			And Not Exists (
        	        Select * From iexp..w_Xso With (Nolock)
        	        Where iexp..w_Xso.client_code = Sapi..SP33.clientcode 
					And iexp..w_Xso.erp_site = Sapi..SP33.werks  
					And iexp..w_Xso.cust_po_number = Sapi..SP33.EBELN
					And Sapi..SP33.BSART = 'ZS04' 
					And Substring(Sapi..SP33.werks,1,1) = 'E'
					)
			Group by clientcode , werks  , edlinf , EBELN  , Sapi..SP33.sfile , value5 , RESWK , Iexp..m_Storer_S.site_name_full , 
        	    Iexp..m_Storer_S.site_name , Iexp..m_Storer_S.address , Iexp..m_Storer_S.country , Iexp..m_Storer_S.city , Iexp..m_Storer_S.zip_code ,
        	    Iexp..m_Storer_S.fax_number , Iexp..m_Storer_S.phone_number

			Print '單據頭檔新增：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

        	Update Iexp..w_Po 
			Set so_item_count = po_item_count 
			, so_total_qty = po_total_qty          
        	Where display_po_number in (
				Select EBELN From Sapi..SP33 With (Nolock)
				Where etyps = 9 
				And EdlType In ('PO') 
				And BSART = 'ZS04' 
				And Substring(werks,1,1) = 'E' )

		End

		-- End
		--------------------------------

		Delete From Sapi..SP33 Where etyps = 9 And EdlType In ('PO','RPO')
		Print '資料清除：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'    
    End

	Select @RowCount = Count(*) From Sapi..SP33 Where etyps = 9 And EdlType In ('WPO')
	If (@RowCount) > 0 
	Begin
        Print '類型：wPo，w_Po明細轉入數量：' + Cast(@RowCount As varchar(10)) + '筆'
	    
        --加工標記填入
	    --商品類型
	    Update Sapi..SP33 Set vas_flag = 'Y' Where matkl Like '[3,4,5,6,7,F]%' And etyps = 9 
	    Update Sapi..SP33 Set vas_flag = 'Y' Where matkl Like '11[2,3,4,5]%' And etyps = 9 

	    --一號多書
	    Update Sapi..SP33 Set vas_flag = 'Y' 
		    From (Select client_code , erp_site , display_item_number , oean  From iexp..m_Sku ) As m_Sku 
	    Where Sapi..SP33.clientcode = m_Sku.client_code And Sapi..SP33.werks = m_Sku.erp_site 
		    And Sapi..SP33.MATNR = m_Sku.display_item_number And Isnull(m_Sku.oean ,'') <> '' And Sapi..SP33.etyps = 9 
	    --加工標記填入

        Delete Iexp..w_Pod 
			From Iexp..w_Pod As w_Pod , 
				( Select clientcode , werks , value5  From Sapi..SP33 Where etyps = 9 And edltype In ('WPO') Group by clientcode , werks , value5 ) As SP33 
			Where w_Pod.client_code = SP33.clientcode And w_Pod.erp_site = SP33.werks And w_Pod.display_po_number = SP33.value5 
		Print '相同單據的明細全部刪除：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

        Insert Into Iexp..w_Pod ( 
			client_code						, erp_site						, display_po_number					, line_number							, 
			ref_po_number					, ref_line_number				, ref_po_number_2					, ref_line_number_2						, 
			item_number						, uom_qty						, uom_qty_received					, uom_qty_damaged						,
			order_uom						, qty							, qty_received						, qty_damaged							, 
			base_uom						, tax_code						, list_price						, discount								, 
			cost							, vas_flag						, vas								, packing_flag							,
			packing							, expiration_control_flag		, value_flag						, fragile_flag							, 
			lot_number						, lot_number_2					, lot_number_3						, lot_number_4							, 
			lot_number_5					, qty_diff						, qty_diff_over						, qty_diff_under						,
			qty_diff_barcode				, qty_diff_noean				, qty_diff_stain					, qty_diff_damaged						, 
			qty_diff_misc					, diff_misc_description			, diff_memo							, Adddate								, 
			Addwho							, Editdate						, Editwho							, comment								,
			Ex1								, Ex2							, Ex3								, Ex4									, 
			Ex5								, Ex6							, Ex7								, Ex8									,
            Etyps                           )
		Select 
			SP33.clientcode					, SP33.werks					, SP33.value5     					, Case When SP33.value5 Like '5%' Then dbo.FmtNumStr(Cast(EBELP As int),10,0) Else dbo.FmtNumStr(Cast(value6 As int),10,0) End,
			SP33.EBELN 						, dbo.FmtNumStr(Cast(EBELP As int),10,0), SP33.value5				, Case When SP33.value5 Like '5%' Then dbo.FmtNumStr(Cast(EBELP As int),10,0) Else dbo.FmtNumStr(Cast(value6 As int),10,0) End,
			MATNR         					, Cast(WAMNG As numeric)		, 0								    , 0										,
			meins							, Cast(WAMNG As numeric)		, 0								    , 0										,
			meins							, Null							, Cast(Isnull(m_Sku.list_price,0.00) As money ), m_Sku.discount				,
			Cast(Isnull(m_sku.cost,0.00) As money), Isnull(vas_flag,'N')	, Null								, 'N'									,
			Null							, m_sku.expiration_date_control	, Isnull(Left(m_sku.value_description,1),'N'), m_sku.haz_material			,
			Null							, Isnull(ZOMSNM,ZECNUM )		, Lgort								, Null									,
			Null							, 0								, 0									, 0										,
			0								, 0								, 0									, 0										,
			0								, Null							, Null								, Getdate()								,
			'GateWay_InterFace'				, Getdate()						, 'GateWay_InterFace'				, Null									,
			Null							, Null							, Null								, Null									,
			Null							, Null							, Null								, Null									,
            9
		From Sapi..SP33 As SP33 With (Nolock)  
		Left Join Iexp..m_Sku As m_Sku 
		On SP33.clientcode = m_Sku.client_code 
		And SP33.werks = m_Sku.erp_site 
		And SP33.EBELN = m_Sku.display_item_number 
		Where SP33.etyps = 9 And EdlType In ('WPO')

		Print '單據明細新增：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

		Update Iexp..w_Po Set 
			po_item_count = SP33.po_item_count	, po_total_qty = SP33.po_total_qty		, vas_flag = SP33.vas_flag		,
			packing_flag = SP33.packing_flag	, expiration_control_flag = SP33.expiration_control_flag , value_flag = SP33.value_flag ,
			fragile_flag = SP33.fragile_flag	, create_date = SP33.create_date		, Efile = SP33.Efile			,
			Editdate = Getdate()				, Editwho = 'GateWay_InterFace'
		From (
			Select 
				clientcode As client_code					, werks As erp_site			, value5 As display_po_number			, 
				Count(Distinct MATNR ) As po_item_count		, Sum(Cast(WAMNG As numeric)) As po_total_qty	, 
				Case Sum(Case vas_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As vas_flag , 
				Case Sum(Case packing_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End	As packing_flag ,
				Case Sum(Case expiration_control_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As expiration_control_flag , 
				Case Sum(Case value_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As value_flag , 
				Case Sum(Case fragile_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As fragile_flag , 
				Cast(Max(BUDAT) As smalldatetime )  As create_date , Sfile As Efile
			From Sapi..SP33 With (Nolock)
			Where etyps = 9 And EdlType In ('WPO')
				Group By clientcode , werks ,  Sfile , value5 ) As SP33
		Where Iexp..w_Po.client_code = SP33.client_code And Iexp..w_Po.erp_site = SP33.erp_site 
			And Iexp..w_Po.display_po_number = SP33.display_po_number
		Print '相同單據頭檔更新：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

		Insert Into Iexp..w_Po (
			client_code						, erp_site						, Erp_type_text						, type_text								,
			display_po_number				, po_item_count					, so_item_count						, po_total_qty							,
			so_total_qty					, rcv_total_qty					, vendor_code						, vendor_so_number						,
			vendor_so_number_2				, vendor_case_count				, vendor_total_qty					, xdock_line_id							,
			xdock_period					, xdock_device_id				, vas_flag							, packing_flag							,
			expiration_control_flag			, value_flag					, fragile_flag						, create_date							,
			Etyps							, Efile							, Edate								, Espdate								, 
			Rdate							, Rspdate						, Ctyps								, Cfile									,
			Cdate							, Cspdate						, B2Btyps							, B2Bfile								,
			B2Bdate							, B2Bspdate						, Adddate							, Addwho								,
			Editdate						, Editwho						, comment							, Ex1									,
			Ex2								, Ex3							, Ex4								, Ex5									,
			Ex6								, Ex7							, Ex8								)
		Select 
			clientcode						, werks							, Max(bsart)						, EdlType								,
			value5 							, Count(Distinct MATNR ) 		, 0									, Sum(Cast(WAMNG As numeric))			,
			0								, 0								, RESWK 							, Null									,
			Null							, Null							, Null								, Null									,
			Null							, Null							, Case Sum(Case vas_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End , Case Sum(Case packing_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End	,
			Case Sum(Case expiration_control_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End , Case Sum(Case value_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End , Case Sum(Case fragile_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End , Max(BUDAT)  ,
			9								, sfile							, Getdate()							, Convert(nvarchar(6), Getdate() , 12)	,
			Null							, Null							, 0									, Null									,
			Null							, Null							, 0									, Null									,
			Null							, Null							, Getdate()							, 'GateWay_InterFace'					,
			Getdate()						, 'GateWay_InterFace'			, Null								, Null									,
			Null							, Null							, Null								, Null									,
			Null							, Null							, Null								
		From Sapi..SP33 With (Nolock)
			Where etyps = 9 And EdlType In ('WPO')
				And Not Exists (Select * From iexp..w_Po 
									Where iexp..w_Po.client_code = Sapi..SP33.clientcode And iexp..w_Po.erp_site = Sapi..SP33.werks And iexp..w_Po.display_po_number = Sapi..SP33.value5 )
		Group by clientcode , werks , edlinf , value5 , RESWK , sfile , EdlType
		Print '單據頭檔新增：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

		Delete From Sapi..SP33 Where etyps = 9 And EdlType In ('WPO')
		Print '資料清除：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'    
    End

	--資料回填SJOB
	Update SJOB.dbo.JOBQ set rdo = 9 , udate = getdate() , tscount =@it33 , lotKey1 = @Key1 , lotKey2 = @Key2    , lotKey3 = @Key3  
		--From  ( 
		--	Select Asfile = sfile , its=count(*) , Key1=MAX(clientcode), Key2=MAX(Sfile) 
		--		From SAPi..Sp33
		--	Where sfile = @sfile Group By sfile ) As A  
	    Where sfile = @sfile
	--資料回填SJOB



End