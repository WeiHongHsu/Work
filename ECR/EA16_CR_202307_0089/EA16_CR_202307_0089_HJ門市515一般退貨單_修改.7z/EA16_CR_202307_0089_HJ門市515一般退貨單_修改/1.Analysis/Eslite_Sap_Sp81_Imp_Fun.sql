
/**** =============================================================================================
 Author			: Calvin
 Create Date	: 2020.03.26
 Description	: Sap SP81 單據轉入w_Po，w_So
 Test SQL		: Exec  Eslite_Sap_Sp81_Imp_Fun '','','Sa' ,'D:\SJOB\IMP\SP8112124110721494145013.PUB' ,''
   
 =============================================================================================****/
CREATE PROCEDURE [dbo].[Eslite_Sap_Sp81_Imp_Fun] ( 
	@Mod1 NVarchar(10), @Mod2 NVarchar(10) , 
	@UserID NVarchar(10) , @Sfile Nvarchar(200) ,
	@Msg1 NVarchar(100) Output 
	)
AS
BEGIN
	--變數宣告
	DECLARE @SPNo AS Int = 0 , @RowCount As Int
	--變數宣告
	Print 'Eslite_Sap_Sp81_Imp_Fun 主檔匯入 Start'

	--資料回填SJOB
	SET NOCOUNT ON;

	--整批備份
 	--資料回填SJOB
	DECLARE @it81 AS Int  , @Key1 As Varchar(30)  , @Key2 As Varchar(30)   , @Key3 As Varchar(30) , @Key4 As Varchar(30) ,  @Cntl as int=0
	--Select  top 1 @it81=count(*) , @Key1=MAX(clientcode), @Key2=MAX(s010)  ,  @Key3=EdlType , @Cntl=max(etyps)  From SAPi..Sp81   Group By sfile
	--Update  pJOBQ set rdo = 8 , udate = getdate() , tscount = @it81 , lotKey1 = @Key1 , lotKey2 = @Key2   ,  lotKey3=EdlType
	--	from SJOB.dbo.JOBQ pJOBQ   WITH (INDEX (INDX_JOBQ_sfile))    Where sfile = @sfile
 

	--資料確認
	IF EXISTS(Select  *  From Sapi..SP81 Where sfile <> @sfile ) Begin
		Delete From Sapi..SP81 Where sfile <> @sfile
		Print '刪除多餘Recode：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'
	END
	Update Sapi..SP81 Set etyps = 1 , @SPNo = 1 Where etyps = 0
	Update SAPi..SP81 Set  werks='F003'   where werks like 'F20%' and bsart='ZR01' 
	Update SAPi..SP81 Set 
		etyps = case when Isnull (_ErpImpLogic.EDLType ,'')='' then -1199 else 9 end ,
		werks = _ErpImpLogic.Erp_Site_Re , EdlInf = _ErpImpLogic.EDLInf ,EdlType = _ErpImpLogic.EDLType
        -- Sap未給倉別先壓上倉別
        , LGORT = _ErpImpLogic.Erp_Site_Ex_Re 
 	from  _ErpImpLogic With (nolock) where InterFace = 'SP81' 
		And _ErpImpLogic.client_code = SAPi..SP81.clientcode 
		And _ErpImpLogic.Erp_Site = SAPi..SP81.werks 
		And _ErpImpLogic.ErpType = SAPi..SP81.bsart and  _ErpImpLogic.EDLInf In ('PO' ,'RPO') 
		And Sapi..SP81.etyps = 1 And _ErpImpLogic.Etyps = 9
	Print 'PO Tag ：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

    Update SAPi..SP81 Set 
		etyps = case when Isnull (_ErpImpLogic.EDLType ,'')='' then -1199 else 9 end ,
		s012  = _ErpImpLogic.Erp_Site_Re , EdlInf = _ErpImpLogic.EDLInf ,EdlType = _ErpImpLogic.EDLType 
 	from  _ErpImpLogic where InterFace = 'SP81' 
		And		_ErpImpLogic.client_code = SAPi..SP81.clientcode 
		And  _ErpImpLogic.Erp_Site =case when _ErpImpLogic.EDLType='SO' then  SAPi..SP81.s012    else SAPi..SP81.werks   end  
		And _ErpImpLogic.ErpType = SAPi..SP81.bsart and  _ErpImpLogic.EDLInf In ('SO') 
		And Sapi..SP81.etyps = 1 And _ErpImpLogic.Etyps = 9
	Print 'SO Tag ：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

	--Update SAPi..SP81 Set 
	--	etyps = case when Isnull (_ErpImpLogic.EDLType ,'')='' then -1199 else 9 end ,
	--	werks = _ErpImpLogic.Erp_Site_Re , EdlInf = _ErpImpLogic.EDLInf ,EdlType = _ErpImpLogic.EDLType
 --       -- Sap未給倉別先壓上倉別
 --       , LGORT = _ErpImpLogic.Erp_Site_Ex_Re 
 --	from  _ErpImpLogic With (nolock) where InterFace = 'SP81' 
	--	And _ErpImpLogic.client_code = SAPi..SP81.clientcode 
	--	And _ErpImpLogic.Erp_Site = SAPi..SP81.werks 
	--	And _ErpImpLogic.ErpType = SAPi..SP81.bsart and  _ErpImpLogic.EDLInf In ('SO') And _ErpImpLogic.EDLType In ('RSO') 
	--	And Sapi..SP81.etyps = 1 And _ErpImpLogic.Etyps = 9
	--	Print 'RSO Tag ：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'
	---- 未定  單型
	--Update SAPi..SP81 Set  etyps = -100  where  
	--	 NOT exists ( select * from  Iexp.._ErpImpLogic  as Tg  where Erp_Site=ORGUID2 and bsart=ErpType )

	--資料確認
		
	--異常資料處理
	Update SP81 Set etyps = - 1170 From Sapi..SP81 As SP81 , w_Po 
		Where SP81.clientcode = w_Po.client_code And SP81.werks = w_Po.erp_site And SP81.s010 = w_Po.display_po_number 
			And w_Po.Ctyps <> 0 And SP81.EdlInf In ('PO'   ) And SP81.etyps = 9 
	Print 'PO重複單據數量：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'  

	Update SP81 Set etyps = - 1170 From Sapi..SP81 As SP81 , w_So 
		Where SP81.clientcode = w_So.client_code And w_So.erp_site=Case when EdlType='SO'  then SP81.s012  else SP81.werks  end
			And SP81.s010 = w_So.display_order_number  
			And w_So.Ctyps <> 0 And SP81.EdlInf In ('So') And SP81.etyps = 9 
	Print 'So重複單據數量：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'
	

	Select  bsart, werks, S012 , s010 , EdlInf ,EdlType , Count(*) From Sapi..SP81 Where etyps=9 group by bsart, werks, S012 , s010 , EdlInf ,EdlType
	--異常資料處理
    -- STATE report   bsart /     S012 /S014 ,  werks
    Select  top 1 @it81=count(*)  , @Key3 =max(bsart ) , @Key1=case when MAX(S012)='' then MAX(S014) else MAX(S012) end +' To '+ max(werks)   , @Key2=MAX(s010)  ,  @Key4=max(EdlType) , @Cntl=max(etyps)  From SAPi..Sp81   Group By sfile
    Print   @Key1  + ' 單(類型):'+ @Key2 +' (' +@Key4+ ' /' +@Key2+  ')：'+ + Cast(@it81 as varchar(6)) + ' 筆 Types: ' + Cast(@Cntl  as varchar(6))

	--整批備份
	Insert Into Sapi..SP81_BK Select * From Sapi..SP81 

	Select @RowCount = Count(*) From Sapi..SP81 Where etyps = 9 And EdlInf In  ('PO' ,'RPO') 
	--資料轉入PO
	If (@RowCount) > 0 
	Begin
		Print 'w_Po明細轉入數量：' + Cast(@RowCount As varchar(10)) + '筆'
        -- 誠生訂單轉成PO_M2
        Update Sapi..SP81 Set edltype = edltype+'_M2' Where s014 in ('0000217850','0000222074')
	    --加工標記填入
	    --供應商國別
	    Update Sapi..SP81 Set vas_flag = 'Y' 
		    From (Select client_code , vendor_code , country  From m_Storer_V ) As m_Storer_V
	    Where Sapi..SP81.clientcode = m_Storer_V.client_code And Sapi..SP81.s014 = m_Storer_V.vendor_code And m_Storer_V.country <> 'TW' 
		    And Sapi..SP81.etyps = 9 
	    --單型
	    Update Sapi..SP81 Set vas_flag = 'Y' 
		    Where bsart In  ('ZP71','ZP72','ZP73','ZP74','ZP75','ZP76','ZP77','ZP78','ZP91','ZP92','ZP93','ZP94','ZP95','ZP96','ZP97','ZP98','ZP99')
			    And etyps = 9 
	    --商品類型
	    Update Sapi..SP81 Set vas_flag = 'Y' Where matkl Like '[3,4,5,6,7,F]%' And etyps = 9 
	    Update Sapi..SP81 Set vas_flag = 'Y' Where matkl Like '11[2,3,4,5]%' And etyps = 9 

	    --一號多書
	    Update Sapi..SP81 Set vas_flag = 'Y' 
		    From (Select client_code , erp_site , display_item_number , oean  From iexp..m_Sku ) As m_Sku 
	    Where Sapi..SP81.clientcode = m_Sku.client_code And Sapi..SP81.werks = m_Sku.erp_site 
		    And Sapi..SP81.s021 = m_Sku.display_item_number And Isnull(m_Sku.oean ,'') <> '' And Sapi..SP81.etyps = 9 
	    --加工標記填入

		Delete Iexp..w_Pod 
			From Iexp..w_Pod As w_Pod , 
				( Select clientcode , werks , S010 From Sapi..SP81 Where etyps = 9 And EdlInf In ('Po') Group by clientcode , werks , S010 ) As SP81 
			Where w_Pod.client_code = SP81.clientcode And w_Pod.erp_site = SP81.werks And w_Pod.display_po_number = SP81.s010 
		Print '相同單據的明細全部刪除：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

		Insert Into Iexp..w_Pod ( 
			client_code						, erp_site						, display_po_number					, line_number							, 
			ref_po_number					, ref_line_number				, ref_po_number_2					, ref_line_number_2						, 
			item_number						, uom_qty						, uom_qty_received					, uom_qty_damaged						,
			order_uom						, qty							, qty_received						, qty_damaged							, 
			base_uom						, tax_code						, list_price						, discount								, 
			cost							, vas_flag						, vas								, packing_flag							,
			packing							, expiration_control_flag		, value_flag						, fragile_flag							, 
			lot_number						, lot_number_2					, lot_number_3						, lot_number_4							, 
			lot_number_5					, qty_diff						, qty_diff_over						, qty_diff_under						,
			qty_diff_barcode				, qty_diff_noean				, qty_diff_stain					, qty_diff_damaged						, 
			qty_diff_misc					, diff_misc_description			, diff_memo							, Adddate								, 
			Addwho							, Editdate						, Editwho							, comment								,
			Ex1								, Ex2							, Ex3								, Ex4									, 
			Ex5								, Ex6							, Ex7								, Ex8									,
            Etyps                           )
		Select  DISTINCT 
			SP81.clientcode					, SP81.werks					, SP81.s010							, dbo.FmtNumStr(Cast(s015 As int),10,0) ,
			SP81.s010						, dbo.FmtNumStr(Cast(s015 As int),10,0), SP81.s010					, dbo.FmtNumStr(Cast(s015 As int),10,0)	,
			s021        					, Cast(Cast(s016 As money )As numeric), 0							, 0										,
			meins							, Cast(Cast(s016 As money )As numeric), 0							, 0										,
			meins							, Null							, Cast(Isnull(m_Sku.list_price,0.00) As money ), m_Sku.discount				,
			Cast(Isnull(m_sku.cost,0.00) As money), Isnull(vas_flag,'N')	, Null								, 'N'									,
			Null							, m_sku.expiration_date_control	, Isnull(Left(m_sku.value_description,1),'N'), m_sku.haz_material			,
			Null							, Isnull(ZOMSNM,ZECNUM )		, Lgort								, Null									,
			Null							, 0								, 0									, 0										,
			0								, 0								, 0									, 0										,
			0								, Null							, Null								, Getdate()								,
			'GateWay_InterFace'				, Getdate()						, 'GateWay_InterFace'				, Line									,
			inventory_type		, preferred_Y				, ean									, Null									,
			Null							, Null							, Null								, Null                                  ,
            9
		From Sapi..SP81 As SP81 Left Join Iexp..m_Sku As m_Sku 
				On SP81.clientcode = m_Sku.client_code And SP81.werks = m_Sku.erp_site And SP81.s021 = m_Sku.display_item_number 
		Where SP81.etyps = 9 And EdlInf In ('Po')  
						and NOT  exists(select * from  Iexp..w_Pod where display_PO_number=S010 and  line_number= dbo.FmtNumStr(Cast(s015 As int),10,0) )
		Print '單據明細新增：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

		Update Iexp..w_Po Set 
			po_item_count = SP81.po_item_count	, po_total_qty = SP81.po_total_qty		, vas_flag = SP81.vas_flag		,
			packing_flag = SP81.packing_flag	, expiration_control_flag = SP81.expiration_control_flag , value_flag = SP81.value_flag ,
			fragile_flag = SP81.fragile_flag	, create_date = SP81.create_date		, Efile = SP81.Efile			,
			Editdate = Getdate()				, Editwho = 'GateWay_InterFace'         , Etyps = 9
		From (
			Select 
				clientcode As client_code					, werks As erp_site			, s010 As display_po_number			, 
				Count(Distinct s021) As po_item_count		, Sum(Cast(Cast(s016 As money )As numeric)) As po_total_qty	, 
				Case Sum(Case vas_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As vas_flag , 
				Case Sum(Case packing_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End	As packing_flag ,
				Case Sum(Case expiration_control_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As expiration_control_flag , 
				Case Sum(Case value_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As value_flag , 
				Case Sum(Case fragile_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As fragile_flag , 
				Max(eindt) As create_date , Sfile As Efile
			From Sapi..SP81 Where etyps = 9 And EdlInf In ('Po')
				Group By clientcode , werks , Sfile , s010 ) As SP81
		Where Iexp..w_Po.client_code = SP81.client_code And Iexp..w_Po.erp_site = SP81.erp_site 
			And Iexp..w_Po.display_po_number = SP81.display_po_number
		Print '相同單據頭檔更新：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

		Insert Into Iexp..w_Po (
			client_code						, erp_site						, Erp_type_text						, type_text								,
			display_po_number				, po_item_count					, so_item_count						, po_total_qty							,
			so_total_qty					, rcv_total_qty					, vendor_code						, vendor_so_number						,
			vendor_so_number_2				, vendor_case_count				, vendor_total_qty					, xdock_line_id							,
			xdock_period					, xdock_device_id				, vas_flag							, packing_flag							,
			expiration_control_flag			, value_flag					, fragile_flag						, create_date							,
			Etyps							, Efile							, Edate								, Espdate								, 
			Rdate							, Rspdate						, Ctyps								, Cfile									,
			Cdate							, Cspdate						, B2Btyps							, B2Bfile								,
			B2Bdate							, B2Bspdate						, Adddate							, Addwho								,
			Editdate						, Editwho						, comment							, Ex1									,
			Ex2								, Ex3							, Ex4								, Ex5									,
			Ex6								, Ex7							, Ex8								)
		Select DISTINCT
			clientcode						, werks							, bsart								, EdlType								,
			s010							, Count(Distinct s021)			, 0									, Sum(Cast(Cast(s016 As money )As numeric)),
			0								, 0								, s014								, Null									,
			Null							, Null							, Null								, Null									,
			Null							, Null							, Case Sum(Case vas_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End , Case Sum(Case packing_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End	,
			Case Sum(Case expiration_control_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End , Case Sum(Case value_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End , Case Sum(Case fragile_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End , Max(eindt) ,
			9								, sfile							, Getdate()							, Convert(nvarchar(6), Getdate() , 12)	,
			Null							, Null							, 0									, Null									,
			Null							, Null							, 0									, Null									,
			Null							, Null							, Getdate()							, 'GateWay_InterFace'					,
			Getdate()						, 'GateWay_InterFace'			, Null								, Null									,
			Null							, Null							, Null								, Null									,
			Null							, Null							, Null								
		From Sapi..SP81
			Where etyps = 9 And EdlInf In ('Po') 
				And Not Exists (Select * From iexp..w_Po 
									Where iexp..w_Po.client_code = Sapi..SP81.clientcode And iexp..w_Po.erp_site = Sapi..SP81.werks And iexp..w_Po.display_po_number = Sapi..SP81.s010 )
		Group by clientcode , werks , bsart , edlinf , s010 , s014 ,  sfile , EdlType
		Print '單據頭檔新增：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

		 Delete From Sapi..SP81 Where etyps = 9 And EdlInf In ('Po')  and Exists (Select * From iexp..w_Po Where display_po_number =  s010 )
		--Print '資料清除：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'
	End

	Select @RowCount = Count(*) From Sapi..SP81 Where etyps = 9 And EdlInf In ('So') And edltype in ('SO')
	If (@RowCount) > 0 
	Begin
		Print 'w_So明細轉入數量：' + Cast(@RowCount As varchar(10)) + '筆'
	    --加工標記填入
	    --商品類型
	    Update Sapi..SP81 Set vas_flag = 'Y' Where matkl Like '[3,4,5,6,7,F]%' And etyps = 9 
	    Update Sapi..SP81 Set vas_flag = 'Y' Where matkl Like '11[2,3,4,5]%' And etyps = 9 

	    --一號多書
	    Update Sapi..SP81 Set vas_flag = 'Y' 
		    From (Select client_code , erp_site , display_item_number , oean  From iexp..m_Sku ) As m_Sku 
	    Where Sapi..SP81.clientcode = m_Sku.client_code And Sapi..SP81.werks = m_Sku.erp_site 
		    And Sapi..SP81.s021 = m_Sku.display_item_number And Isnull(m_Sku.oean ,'') <> '' And Sapi..SP81.etyps = 9 
	    --加工標記填入

		Delete Iexp..w_Sod 
			From Iexp..w_Sod As w_Sod , 
				( Select clientcode , s012 , S010 From Sapi..SP81 Where etyps = 9 And EdlInf In ('So') Group by clientcode , s012 , S010 ) As SP81 
			Where w_Sod.client_code = SP81.clientcode And w_Sod.erp_site = SP81.s012 And w_Sod.Display_order_number = SP81.s010 
		Print '相同單據的明細全部刪除：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

        --更新物流作業類型（expo）
        update Sapi..SP81 Set edltype = 'RSO_M2' Where s014 in ('0000215232','0000222074') And werks in ('C001','G016')

        Insert Into w_Sod (
            client_code                     , erp_site                      , Display_order_number              , Display_order_line_number             ,
            cust_po_number                  , po_line_number                , order_number                      , order_line_number                     ,
            item_number                     , uom_qty                       , uom_qty_shipped                   , order_uom                             ,
            qty                             , qty_shipped                   , qty_return                        , base_uom                              ,
            tax_rate                        , invoice_number                , invoice_dt                        , invoice_amount                        , 
            currency_code                   , tax_code                      , untax_amount                      , tax_amount                            ,
            amount                          , invoice_code                  , list_price                        , discount                              ,
            cost                            , vas_flag                      , packing_flag                      , expiration_control_flag               ,
            value_flag                      , fragile_flag                  , lot_numer                         , lot_number_2                          ,
            lot_number_3                    , lot_number_4                  , lot_number_5                      , oms_hold_number                       ,
            qty_diff                        , qty_diff_over                 , qty_diff_under                    , qty_diff_barcode                      ,
            qty_diff_noean                  , qty_diff_stain                , qty_diff_damaged                  , qty_diff_misc                         ,
            diff_misc_description           , diff_memo                     , Adddate                           , Addwho                                ,
            Editdate                        , Editwho                       , comment                           , Ex1                                   ,
            Ex2                             , Ex3                           , Ex4                               , Ex5                                   ,
            Ex6                             , Ex7                           , Ex8                               )
        Select DISTINCT
            Sp81.clientcode                 , Sp81.s012                     , Sp81.s010                         , dbo.FmtNumStr(Cast(s015 As int),10,0) ,
            '' As cust_po_number            , '' As po_line_number          , '' As order_number                , '' As order_line_number               ,
            s021 As item_number             , Cast(Cast(s016 As money )As numeric) As uom_qty , 0 As uom_qty_shipped , meins As order_uom               ,
            Cast(Cast(s016 As money )As numeric) As Qty , 0 As qty_shipped  , 0 As qty_return                   , meins As base_uom                     ,
            Null As tax_rate                , Null As invoice_number        , Null As invoice_dt                , Null As invoice_amount                , 
            Null As currency_code           , Null As tax_code              , Null As untax_amount              , Null As tax_amount                    ,
            Null As amount                  , Null As invoice_code          , Null As list_price                , Null As discount                      ,
            Null As cost                    , Isnull(vas_flag , 'N')        , 'N' As packing_flag               , Isnull(m_sku.expiration_date_control,'N') As expiration_control_flag ,
            Isnull(Left(m_sku.value_description,1),'N') As value_flag , Isnull(m_sku.haz_material,'N') As fragile_flag , Null As lot_numer , Null As lot_number_2 ,
            case when Sp81.s012='1300' then 'PU01' else  Lgort end As lot_number_3           , Null As lot_number_4          , Null As lot_number_5              , ZOMSNM As oms_hold_number             ,
            0 As qty_diff                   , 0 As qty_diff_over            , 0 As qty_diff_under               , 0 As qty_diff_barcode                 ,
            0 As qty_diff_noean             , 0 As qty_diff_stain           , 0 As qty_diff_damaged             , 0 As qty_diff_misc                    ,
            Null As diff_misc_description   , Null As diff_memo             , Getdate() As Adddate              , 'GateWay_InterFace' As Addwho         ,
            Getdate() As Editdate           , 'GateWay_InterFace' As Editwho, Null As comment                   , Null As Ex1                           ,
            Null As Ex2                     , Null As Ex3                   , Null As Ex4                       , Null As Ex5                           ,
            Null As Ex6                     , Null As Ex7                   , Null As Ex8                               
        From Sapi..Sp81 As Sp81 Left Join Iexp..m_Sku As m_Sku 
            On Sp81.clientcode = m_Sku.client_code And Sp81.werks = m_Sku.erp_site And Sp81.s021 = m_Sku.display_item_number 
        Where Sp81.etyps = 9 And EdlInf In ('So') --And edltype In ('So')
        Print 'SO單據明細新增：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

        Update Iexp..w_So Set 
            So_item_count = Temp.item_count	, So_total_qty = Temp.total_qty		, vas_flag = Temp.vas_flag		,
            packing_flag = Temp.packing_flag	, expiration_control_flag = Temp.expiration_control_flag , value_flag = Temp.value_flag ,
            fragile_flag = Temp.fragile_flag	, Efile = Temp.Efile			,
            Editdate = Getdate()				, Editwho = 'GateWay_InterFace'
        From (
            Select 
                clientcode As client_code					, werks As erp_site			, s010 As display_order_number			, 
                Count(Distinct s021) As item_count		, Sum(Cast(Cast(s016 As money )As numeric)) As total_qty	, 
                Case Sum(Case vas_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As vas_flag , 
                Case Sum(Case packing_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End	As packing_flag ,
                Case Sum(Case expiration_control_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As expiration_control_flag , 
                Case Sum(Case value_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As value_flag , 
                Case Sum(Case fragile_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As fragile_flag , 
                Max(eindt) As eindt ,  Sfile As Efile
            From Sapi..Sp81 Where etyps = 9 And EdlInf In ('So') --And edltype In ('So')
                Group By clientcode , werks , Sfile , s010 ) As Temp
        Where Iexp..w_So.client_code = Temp.client_code And Iexp..w_So.erp_site = Temp.erp_site 
            And Iexp..w_So.display_order_number = Temp.display_order_number
        Print '相同單據頭檔更新：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

        Insert Into w_So (
            client_code                     , erp_site                      , Erp_type_text                     , type_text                             ,
            display_order_number            , cust_po_number                , so_total_qty                      , so_item_count                         ,
            so_total_fulfill_qty            , customer_code                 , ship_to_email                     , ship_to_code                          ,
            ship_to_description             , ship_to_name                  , ship_to_address                   , ship_to_country_name                  ,
            ship_to_state                   , ship_to_city                  , ship_to_zip                       , ship_to_fax                           ,
            ship_to_phone                   , cod_type                      , cod_flag                          , cod_amount                            ,
            actual_delivery_date            , total_amount                  , print_invoice                     , bill_to_email                         ,
            bill_to_code                    , bill_to_description           , bill_to_name                      , bill_to_address                       ,
            bill_to_country_name            , bill_to_state                 , bill_to_city                      , bill_to_zip                           ,
            bill_to_fax                     , bill_to_phone                 , vas_flag                          , packing_flag                          ,
            expiration_control_flag         , value_flag                    , fragile_flag                      , Etyps                                 ,
            Efile                           , Edate                         , Espdate                           , Ctyps                                 ,
            Cfile                           , Cdate                         , Cspdate                           , B2Btyps                               ,
            B2Bfile                         , B2Bdate                       , B2Bspdate                         , Adddate                               ,
            Addwho                          , Editdate                      , Editwho                           , comment                               ,
            Ex1                             , Ex2                           , Ex3                               , Ex4                                   ,
            Ex5                             , Ex6                           , Ex7                               , Ex8                                   )
        Select
            Sp81.clientcode As client_code  , s012 As erp_site             , bsart As Erp_type_text            , edltype As type_text                  ,
            s010 As display_order_number    , '' As cust_po_number , Sum(Cast(Cast(s016 As money )As numeric)) As so_total_qty , Count(Distinct s021) As so_item_count ,
            0 As so_total_fulfill_qty       , 'ESL' As customer_code        , '' As ship_to_email               , werks As ship_to_code                  ,
            Iexp..m_Storer_S.site_name_full As ship_to_description , Iexp..m_Storer_S.site_name As ship_to_name , Iexp..m_Storer_S.address As ship_to_address , Iexp..m_Storer_S.country As ship_to_country_name ,
            '' As ship_to_state             , Iexp..m_Storer_S.city As ship_to_city , Iexp..m_Storer_S.zip_code As ship_to_zip , Iexp..m_Storer_S.fax_number As ship_to_fax  ,
            '' As ship_to_phone             , Null As cod_type              , 'N' As cod_flag                   , Null As cod_amount                    ,
            Null As actual_delivery_date    , Null As total_amount          , 'N' As print_invoice              , '' As bill_to_email                   ,
            werks As bill_to_code           , Iexp..m_Storer_S.site_name_full As bill_to_description , Iexp..m_Storer_S.site_name As bill_to_name  , Iexp..m_Storer_S.address As bill_to_address ,
            Iexp..m_Storer_S.country As bill_to_country_name , '' As bill_to_state , Iexp..m_Storer_S.city As bill_to_city , Iexp..m_Storer_S.zip_code As bill_to_zip ,
            Iexp..m_Storer_S.fax_number As bill_to_fax , Iexp..m_Storer_S.phone_number As bill_to_phone , Case Sum(Case vas_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As vas_flag , 'N' As packing_flag ,
            Case Sum(Case expiration_control_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As expiration_control_flag , Case Sum(Case value_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As value_flag , Case Sum(Case fragile_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As fragile_flag , Case When edltype in ('RSO_M1','RSO_M2') Then 9 Else 15 End As Etyps ,
            Sapi..Sp81.sfile As Efile       , Getdate() As Edate            , Convert(nvarchar(6), Getdate() , 12) As Espdate , 0 As Ctyps              ,
            Null As Cfile                   , Null As Cdate                 , Null As Cspdate                   , Null As B2Btyps                       ,
            Null As B2Bfile                 , Null As B2Bdate               , Null As B2Bspdate                 , Getdate() As Adddate                  ,
            'GateWay_InterFace' As Addwho   , Getdate() As Editdate         , 'GateWay_InterFace' As Editwho    , Null As comment                       ,
            Null As Ex1                     , Null As Ex2                   , Null As Ex3                       , Null As Ex4                           ,
            Null As Ex5                     , Null As Ex6                   , Null As Ex7                       , Null As Ex8                                   
        From Sapi..Sp81 Left Join Iexp..m_Storer_S On Sapi..Sp81.clientcode = Iexp..m_Storer_S.customer_code And Sapi..Sp81.werks = Iexp..m_Storer_S.site_code 
			Where etyps = 9 And EdlInf In ('So')   And Not Exists (
                Select * From iexp..w_So 
                    Where iexp..w_So.client_code = Sapi..Sp81.clientcode And iexp..w_So.erp_site = Sapi..Sp81.s012 And iexp..w_So.display_order_number = Sapi..Sp81.s010 )
		Group by clientcode , werks , bsart , edlinf , s010 , Sapi..Sp81.sfile , s012 , Iexp..m_Storer_S.site_name_full , 
            Iexp..m_Storer_S.site_name , Iexp..m_Storer_S.address , Iexp..m_Storer_S.country , Iexp..m_Storer_S.city , Iexp..m_Storer_S.zip_code ,
            Iexp..m_Storer_S.fax_number , Iexp..m_Storer_S.phone_number , edltype
		Print 'SO單據頭檔新增：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'
	        --Update  pJOBQ set rdo =9 , udate = getdate() , tscount = @it81 , lotKey1 = @Key1 , lotKey2 = @Key2  
		       -- from SJOB.dbo.JOBQ pJOBQ   WITH (INDEX (INDX_JOBQ_sfile))    Where sfile = @sfile
     Delete From Sapi..SP81 Where etyps = 9 And EdlInf In ('So')    and Exists (Select * From iexp..w_So Where display_order_number =  s010 )
		--Print '資料清除：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'
	End
	
	Select @RowCount = Count(*) From Sapi..SP81 Where etyps = 9 And EdlInf In ('So') And edltype in ('Rso')
	If (@RowCount) > 0 
	Begin
		Print 'w_So明細轉入RSO數量：' + Cast(@RowCount As varchar(10)) + '筆'
	    --加工標記填入
	    --商品類型
	    Update Sapi..SP81 Set vas_flag = 'Y' Where matkl Like '[3,4,5,6,7,F]%' And etyps = 9 
	    Update Sapi..SP81 Set vas_flag = 'Y' Where matkl Like '11[2,3,4,5]%' And etyps = 9 

	    --一號多書
	    Update Sapi..SP81 Set vas_flag = 'Y' 
		    From (Select client_code , erp_site , display_item_number , oean  From iexp..m_Sku ) As m_Sku 
	    Where Sapi..SP81.clientcode = m_Sku.client_code And Sapi..SP81.werks = m_Sku.erp_site 
		    And Sapi..SP81.s021 = m_Sku.display_item_number And Isnull(m_Sku.oean ,'') <> '' And Sapi..SP81.etyps = 9 
	    --加工標記填入

	    Delete Iexp..w_Sod 
		    From Iexp..w_Sod As w_Sod , 
			    ( Select clientcode , s012 , S010 From Sapi..SP81 Where etyps = 9 And EdlInf In ('So') Group by clientcode , s012 , S010 ) As SP81 
		    Where w_Sod.client_code = SP81.clientcode And w_Sod.erp_site = SP81.s012 And w_Sod.Display_order_number = SP81.s010 
		Print '相同單據的明細全部刪除：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

        --更新物流作業類型（expo）
        update Sapi..SP81 Set edltype = 'RSO_M2' Where s014 in ('0000215232','0000222074') And werks in ('C001','G016')

        Insert Into w_Sod (
            client_code                     , erp_site                      , Display_order_number              , Display_order_line_number             ,
            cust_po_number                  , po_line_number                , order_number                      , order_line_number                     ,
            item_number                     , uom_qty                       , uom_qty_shipped                   , order_uom                             ,
            qty                             , qty_shipped                   , qty_return                        , base_uom                              ,
            tax_rate                        , invoice_number                , invoice_dt                        , invoice_amount                        , 
            currency_code                   , tax_code                      , untax_amount                      , tax_amount                            ,
            amount                          , invoice_code                  , list_price                        , discount                              ,
            cost                            , vas_flag                      , packing_flag                      , expiration_control_flag               ,
            value_flag                      , fragile_flag                  , lot_numer                         , lot_number_2                          ,
            lot_number_3                    , lot_number_4                  , lot_number_5                      , oms_hold_number                       ,
            qty_diff                        , qty_diff_over                 , qty_diff_under                    , qty_diff_barcode                      ,
            qty_diff_noean                  , qty_diff_stain                , qty_diff_damaged                  , qty_diff_misc                         ,
            diff_misc_description           , diff_memo                     , Adddate                           , Addwho                                ,
            Editdate                        , Editwho                       , comment                           , Ex1                                   ,
            Ex2                             , Ex3                           , Ex4                               , Ex5                                   ,
            Ex6                             , Ex7                           , Ex8                               )
        Select
            Sp81.clientcode                 , Sp81.werks                    , Sp81.s010                         , dbo.FmtNumStr(Cast(s015 As int),10,0) ,
            '' As cust_po_number            , '' As po_line_number          , '' As order_number                , '' As order_line_number               ,
            s021 As item_number             , Cast(Cast(s016 As money )As numeric) As uom_qty , 0 As uom_qty_shipped , meins As order_uom               ,
            Cast(Cast(s016 As money )As numeric) As Qty , 0 As qty_shipped  , 0 As qty_return                   , meins As base_uom                     ,
            Null As tax_rate                , Null As invoice_number        , Null As invoice_dt                , Null As invoice_amount                , 
            Null As currency_code           , Null As tax_code              , Null As untax_amount              , Null As tax_amount                    ,
            Null As amount                  , Null As invoice_code          , Null As list_price                , Null As discount                      ,
            Null As cost                    , Isnull(vas_flag , 'N')        , 'N' As packing_flag               , Isnull(m_sku.expiration_date_control,'N') As expiration_control_flag ,
            Isnull(Left(m_sku.value_description,1),'N') As value_flag , Isnull(m_sku.haz_material,'N') As fragile_flag , Null As lot_numer , Null As lot_number_2 ,
            Lgort As lot_number_3           , Null As lot_number_4          , Null As lot_number_5              , ZOMSNM As oms_hold_number             ,
            0 As qty_diff                   , 0 As qty_diff_over            , 0 As qty_diff_under               , 0 As qty_diff_barcode                 ,
            0 As qty_diff_noean             , 0 As qty_diff_stain           , 0 As qty_diff_damaged             , 0 As qty_diff_misc                    ,
            Null As diff_misc_description   , Null As diff_memo             , Getdate() As Adddate              , 'GateWay_InterFace' As Addwho         ,
            Getdate() As Editdate           , 'GateWay_InterFace' As Editwho, Null As comment                   , Null As Ex1                           ,
            Null As Ex2                     , Null As Ex3                   , Null As Ex4                       , Null As Ex5                           ,
            Null As Ex6                     , Null As Ex7                   , Null As Ex8                               
        From Sapi..Sp81 As Sp81 Left Join Iexp..m_Sku As m_Sku 
            On Sp81.clientcode = m_Sku.client_code And Sp81.werks = m_Sku.erp_site And Sp81.s021 = m_Sku.display_item_number 
        Where Sp81.etyps = 9 And EdlInf In ('So') --And edltype In ('Rso') 
        Print 'RSO單據明細新增：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

        Update Iexp..w_So Set 
            So_item_count = Temp.item_count	, So_total_qty = Temp.total_qty		, vas_flag = Temp.vas_flag		,
            packing_flag = Temp.packing_flag	, expiration_control_flag = Temp.expiration_control_flag , value_flag = Temp.value_flag ,
            fragile_flag = Temp.fragile_flag	, Efile = Temp.Efile			,
            Editdate = Getdate()				, Editwho = 'GateWay_InterFace'
        From (
            Select 
                clientcode As client_code					, werks As erp_site			, s010 As display_order_number			, 
                Count(Distinct s021) As item_count		, Sum(Cast(Cast(s016 As money )As numeric)) As total_qty	, 
                Case Sum(Case vas_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As vas_flag , 
                Case Sum(Case packing_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End	As packing_flag ,
                Case Sum(Case expiration_control_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As expiration_control_flag , 
                Case Sum(Case value_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As value_flag , 
                Case Sum(Case fragile_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As fragile_flag , 
                Max(eindt) As eindt ,  Sfile As Efile
            From Sapi..Sp81 Where etyps = 9 And EdlInf In ('So') --And edltype In ('Rso') 
                Group By clientcode , werks , Sfile , s010 ) As Temp
        Where Iexp..w_So.client_code = Temp.client_code And Iexp..w_So.erp_site = Temp.erp_site 
            And Iexp..w_So.display_order_number = Temp.display_order_number
        Print '相同單據頭檔更新：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

        Insert Into w_So (
            client_code                     , erp_site                      , Erp_type_text                     , type_text                             ,
            display_order_number            , cust_po_number                , so_total_qty                      , so_item_count                         ,
            so_total_fulfill_qty            , customer_code                 , ship_to_email                     , ship_to_code                          ,
            ship_to_description             , ship_to_name                  , ship_to_address                   , ship_to_country_name                  ,
            ship_to_state                   , ship_to_city                  , ship_to_zip                       , ship_to_fax                           ,
            ship_to_phone                   , cod_type                      , cod_flag                          , cod_amount                            ,
            actual_delivery_date            , total_amount                  , print_invoice                     , bill_to_email                         ,
            bill_to_code                    , bill_to_description           , bill_to_name                      , bill_to_address                       ,
            bill_to_country_name            , bill_to_state                 , bill_to_city                      , bill_to_zip                           ,
            bill_to_fax                     , bill_to_phone                 , vas_flag                          , packing_flag                          ,
            expiration_control_flag         , value_flag                    , fragile_flag                      , Etyps                                 ,
            Efile                           , Edate                         , Espdate                           , Ctyps                                 ,
            Cfile                           , Cdate                         , Cspdate                           , B2Btyps                               ,
            B2Bfile                         , B2Bdate                       , B2Bspdate                         , Adddate                               ,
            Addwho                          , Editdate                      , Editwho                           , comment                               ,
            Ex1                             , Ex2                           , Ex3                               , Ex4                                   ,
            Ex5                             , Ex6                           , Ex7                               , Ex8                                   )
        Select
            Sp81.clientcode As client_code  , werks As erp_site             , bsart As Erp_type_text            , edltype As type_text                  ,
            s010 As display_order_number    , '' As cust_po_number , Sum(Cast(Cast(s016 As money )As numeric)) As so_total_qty , Count(Distinct s021) As so_item_count ,
            0 As so_total_fulfill_qty       , 'ESL' As customer_code        , '' As ship_to_email               , s014 As ship_to_code                  ,
            Iexp..m_Storer_S.site_name_full As ship_to_description , Iexp..m_Storer_S.site_name As ship_to_name , Iexp..m_Storer_S.address As ship_to_address , Iexp..m_Storer_S.country As ship_to_country_name ,
            '' As ship_to_state             , Iexp..m_Storer_S.city As ship_to_city , Iexp..m_Storer_S.zip_code As ship_to_zip , Iexp..m_Storer_S.fax_number As ship_to_fax  ,
            '' As ship_to_phone             , Null As cod_type              , 'N' As cod_flag                   , Null As cod_amount                    ,
            Null As actual_delivery_date    , Null As total_amount          , 'N' As print_invoice              , '' As bill_to_email                   ,
            s014 As bill_to_code           , Iexp..m_Storer_S.site_name_full As bill_to_description , Iexp..m_Storer_S.site_name As bill_to_name  , Iexp..m_Storer_S.address As bill_to_address ,
            Iexp..m_Storer_S.country As bill_to_country_name , '' As bill_to_state , Iexp..m_Storer_S.city As bill_to_city , Iexp..m_Storer_S.zip_code As bill_to_zip ,
            Iexp..m_Storer_S.fax_number As bill_to_fax , Iexp..m_Storer_S.phone_number As bill_to_phone , Case Sum(Case vas_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As vas_flag , 'N' As packing_flag ,
            Case Sum(Case expiration_control_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As expiration_control_flag , Case Sum(Case value_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As value_flag , Case Sum(Case fragile_flag When 'Y' Then 1 Else 0 End) When 0 Then 'N' Else 'Y' End As fragile_flag , Case When edltype in ('RSO_M1','RSO_M2') Then 9 Else 15 End As Etyps ,
            Sapi..Sp81.sfile As Efile       , Getdate() As Edate            , Convert(nvarchar(6), Getdate() , 12) As Espdate , 0 As Ctyps              ,
            Null As Cfile                   , Null As Cdate                 , Null As Cspdate                   , Null As B2Btyps                       ,
            Null As B2Bfile                 , Null As B2Bdate               , Null As B2Bspdate                 , Getdate() As Adddate                  ,
            'GateWay_InterFace' As Addwho   , Getdate() As Editdate         , 'GateWay_InterFace' As Editwho    , Null As comment                       ,
            Null As Ex1                     , Null As Ex2                   , Null As Ex3                       , Null As Ex4                           ,
            Null As Ex5                     , Null As Ex6                   , Null As Ex7                       , Null As Ex8                                   
        From Sapi..Sp81 Left Join Iexp..m_Storer_S On Sapi..Sp81.clientcode = Iexp..m_Storer_S.customer_code And Sapi..Sp81.s014 = Iexp..m_Storer_S.site_code 
			Where etyps = 9 And EdlInf In ('So')  And Not Exists (
                Select * From iexp..w_So 
                    Where iexp..w_So.client_code = Sapi..Sp81.clientcode And iexp..w_So.erp_site = Sapi..Sp81.s012 And iexp..w_So.display_order_number = Sapi..Sp81.s010 )
		Group by clientcode , s014 , bsart , edlinf , s010 , Sapi..Sp81.sfile , werks , Iexp..m_Storer_S.site_name_full , 
            Iexp..m_Storer_S.site_name , Iexp..m_Storer_S.address , Iexp..m_Storer_S.country , Iexp..m_Storer_S.city , Iexp..m_Storer_S.zip_code ,
            Iexp..m_Storer_S.fax_number , Iexp..m_Storer_S.phone_number , edltype
		Print 'RSO單據頭檔新增：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'

         Delete From Sapi..SP81 Where etyps = 9 And EdlInf In ('So')  and    Exists (Select * From iexp..w_Po Where display_po_number =  s010 )
		-- Print '資料清除：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'
	End
   
   
   -- <20210523 回JOBQ登記>
	Select  top 1 @it81=count(*) , @Key1=MAX(clientcode)+'-'+ MAX(s013)+' > ' + MAX(werks), @Key2=MAX(s010)  ,  @Key3=max(EdlType) , @Cntl=max(etyps)  From SAPi..Sp81   Group By sfile
	Update  pJOBQ set rdo =case when @Cntl=9 then 9 else 8 end ,tscount=@RowCount  , udate = getdate()  , lotKey1 = @Key1 , lotKey2 = @Key2   ,  lotKey3=@Key3,inCntl=@Cntl
		from SJOB.dbo.JOBQ pJOBQ   WITH (INDEX (INDX_JOBQ_sfile))    Where sfile = @sfile
	 Print '回JOBQ登記：' + Cast(@@ROWCOUNT as varchar(6)) + '筆'  +@sfile

	If (Select Count(*) From Sapi..SP81  ) > 0 
	Begin
		Print '異常資料轉移至異常區'
		Insert Into Sapi..SP81_Error Select * From Sapi..SP81  
		Delete From Sapi..SP81  --Where sfile = @sfile    
	End

   -- Print   @Key2  + ' <'+ @Key1 + '> 單類型'+ @Key3 + '：' + Cast(@@ROWCOUNT as varchar(6)) + '筆 Types:' + Cast(@Cntl  as varchar(6))
    Print 'Eslite_Sap_Sp81_Imp_Fun 主檔匯入 End'
End
