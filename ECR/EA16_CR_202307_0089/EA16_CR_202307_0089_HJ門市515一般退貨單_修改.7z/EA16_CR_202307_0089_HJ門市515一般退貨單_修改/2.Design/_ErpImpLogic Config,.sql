Select Client_Code,interface,ErpType,LogicDesc,LogicMemo,EDLinf,EDLType,WMSType,Erp_Site,Erp_Site_re,Erp_Site_EX_Re,Output_interface1,Etyps
from iexp.dbo._ErpImpLogic with (nolock) 
where interface = 'SP33'
and Erptype IN ('ZS15')


--SP : IEXP.[dbo].[Eslite_Sap_Sp33_Imp_Fun]


Begin tran
Update  iexp.dbo._ErpImpLogic 
SET Erp_Site_Ex_Re = '0004'
where interface = 'SP33'
and Erptype IN ('ZS15')
rollback tran