﻿select * from _t_printer_mapping (nolocK) where report_name = 'HJ_RPT_ShipList_EC'
select * from _t_printer_mapping (nolocK) where report_name = 'HJ_RPT_ShipList_EC_SP'

D:\Bartender\Format\ShippingList\20230823-C001出貨單.jpg
D:\Bartender\Format\ShippingList\20230823-C001出貨單.jpg
D:\Bartender\Format\ShippingList\20230823-G016出貨單.jpg
D:\Bartender\Format\ShippingList\20230823-G016出貨單.jpg
select * from _T_codelkup (nolocK) where listname = 'SHIPlist'  and code = 'ECShipList'
select * from _T_codelkup (nolocK) where listname = 'BTWAPIConfig'  and code = 'ECShipList'

select * from _t_printer_mapping (nolocK) where report_name = 'HJ_RPT_ShipList_EC'
and workstation_id = 'LNWOC210009'
select * from _t_printer_mapping (nolocK) where report_name = 'HJ_RPT_ShipList_EC_SP'
and workstation_id = 'LNWOC210009'

select * from _t_printer_mapping (nolocK) where printer_id = 'CB_192.168.19.181'

--update _t_printer_mapping 
--set BTW_Label  ='D:\Bartender\Format\HJ_RPT_ShipList_EC_SP.btw'
--where report_name = 'HJ_RPT_ShipList_EC_SP'
--and workstation_id = 'LNWOC210009'

--update _t_printer_mapping 
--set BTW_Label  ='D:\Bartender\Format\HJ_RPT_ShipList_EC.btw'
--where report_name = 'HJ_RPT_ShipList_EC'
--and workstation_id = 'LNWOC210009'

--update _t_printer_mapping 
--set BTW_Label  ='lib://HJ_RPT_ShipList_EC_SP.btw'
--where report_name = 'HJ_RPT_ShipList_EC_SP'
--and workstation_id = 'LNWOC210009'

--update _t_printer_mapping 
--set BTW_Label  ='lib://HJ_RPT_ShipList_EC.btw'
--where report_name = 'HJ_RPT_ShipList_EC'
--and workstation_id = 'LNWOC210009'


--lib://HJ_RPT_ShipList_EC.btw
--lib://HJ_RPT_ShipList_EC_SP.btw
select * 
from _t_printer_mapping (nolocK) 
where report_name = 'HJ_RPT_ShipList_EC'
and workstation_id = 'LNWOC210009'

/*更改標籤位置*/
--update _t_printer_mapping 
--set BTW_Label  ='D:\Bartender\Format\HJ_RPT_ShipList_EC.btw'
--where report_name = 'HJ_RPT_ShipList_EC'
--and workstation_id = 'LNWOC210009'
--update _t_printer_mapping 
--set BTW_Label  ='D:\Bartender\Format\HJ_RPT_ShipList_EC_SP.btw'
--where report_name = 'HJ_RPT_ShipList_EC_SP'
--and workstation_id = 'LNWOC210009'

select * from _T_codelkup (nolocK) where listname = 'BTWAPIConfig'  and code = 'ECShipList'

/*更改欄位數*/
--begin tran
--update _T_codelkup set udf04 = '20' where listname = 'BTWAPIConfig'  and code = 'ECShipList'
--rollback tran

/*最新*/
--update _T_codelkup set 
--udf07 = 'D:\Bartender\Format\ShippingList\20230823-C001出貨單.jpg'
--,udf06 = 'D:\Bartender\Format\ShippingList\出貨明細_防詐騙.jpg'
--where listname = 'SHIPlist'  and code = 'ECShipList'
--and Storerkey = 'C001'

--update _T_codelkup set 
--udf07 = 'D:\Bartender\Format\ShippingList\20230823-G016出貨單.jpg'
--,udf06 = 'D:\Bartender\Format\ShippingList\出貨明細_防詐騙.jpg'
--where listname = 'SHIPlist'  and code = 'ECShipList'
--and Storerkey = 'G016'

/*測試*/
--update _T_codelkup set 
--udf07 = 'D:\Bartender\Format\ShippingList\20230615-C001出貨單.jpg'
--where listname = 'SHIPlist'  and code = 'ECShipList'
--and Storerkey = 'C001'

--update _T_codelkup set 
--udf07 = 'D:\Bartender\Format\ShippingList\20230615-G016出貨單.jpg'
--where listname = 'SHIPlist'  and code = 'ECShipList'
--and Storerkey = 'G016'

/*列印測試*/
DECLARE @rtn_code      NVARCHAR(10)    
       ,@rtn_message   NVARCHAR(4000)  
       ,@ww_result     NVARCHAR(10)    
--EXEC _sp_HJ_BTW_RPT_ShipList_EC 'pz1','C001','ESL-202308180874301','JackyHsu','','',@rtn_code OUTPUT,@rtn_message OUTPUT ,@ww_result OUTPUT,'','',''  
--select  @rtn_code,@rtn_message,@ww_result
--EXEC [_sp_HJ_BTW_RPT_ShipList_EC_SP] 'pz1','G016','ESL-210908FWW1HCAV','jackyhsu','','',@rtn_code OUTPUT,@rtn_message OUTPUT ,@ww_result OUTPUT,'','',''
--select  @rtn_code,@rtn_message,@ww_result
EXEC [_sp_EC_ShipList_WMS] 'pz1','G016','230218B31UYN2D','LNWOC210009','','',@rtn_code OUTPUT,@rtn_message OUTPUT ,@ww_result OUTPUT,'','',''  
select  @rtn_code,@rtn_message,@ww_result
EXEC [_sp_EC_ShipList_WMS] 'pz1','DBE1','202308279102501','LNWOC210009','','',@rtn_code OUTPUT,@rtn_message OUTPUT ,@ww_result OUTPUT,'','',''  
select  @rtn_code,@rtn_message,@ww_result
